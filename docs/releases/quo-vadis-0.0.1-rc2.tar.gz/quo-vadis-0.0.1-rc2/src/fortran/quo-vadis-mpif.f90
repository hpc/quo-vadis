!
! Copyright (c) 2013-2025 Triad National Security, LLC
!                         All rights reserved.
!
! This file is part of the quo-vadis project. See the LICENSE file at the
! top-level directory of this distribution.
!

module quo_vadis_mpif
    use, intrinsic :: iso_c_binding
    use quo_vadisf

interface
    integer(c_int) &
    function qv_mpi_scope_c(comm, iscope, flags, scope) &
        bind(c, name='qvi_mpi_scope_get_f2c')
        use, intrinsic :: iso_c_binding, only: c_ptr, c_long_long, c_int
        implicit none
        integer(c_int), value :: comm
        integer(c_int), value :: iscope
        integer(c_long_long), value :: flags
        type(c_ptr), intent(out) :: scope
    end function qv_mpi_scope_c

    integer(c_int) &
    function qv_mpi_comm_dup_c(scope, comm) &
        bind(c, name='qvi_mpi_scope_comm_dup_f2c')
        use, intrinsic :: iso_c_binding, only: c_ptr, c_int
        implicit none
        type(c_ptr), value :: scope
        integer(c_int), intent(out) :: comm
    end function qv_mpi_comm_dup_c

end interface

contains

    subroutine qv_mpi_scope(comm, iscope, flags, scope, info)
        use, intrinsic :: iso_c_binding, only: c_ptr, c_int, c_long_long
        implicit none
        integer, value :: comm
        integer(c_int), value :: iscope
        integer(c_long_long), value :: flags
        type(c_ptr), intent(out) :: scope
        integer(c_int), intent(out) :: info
        info = qv_mpi_scope_c(comm, iscope, flags, scope)
    end subroutine qv_mpi_scope

    subroutine qv_mpi_comm_dup(scope, comm, info)
        use, intrinsic :: iso_c_binding, only: c_ptr, c_int
        implicit none
        type(c_ptr), value :: scope
        integer, intent(out) :: comm
        integer(c_int), intent(out) :: info
        info =  qv_mpi_comm_dup_c(scope, comm)
    end subroutine qv_mpi_comm_dup

end module quo_vadis_mpif

! vim: ft=fortran ts=4 sts=4 sw=4 expandtab
