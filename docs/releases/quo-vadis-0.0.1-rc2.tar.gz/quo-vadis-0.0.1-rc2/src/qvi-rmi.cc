/* -*- Mode: C++; c-basic-offset:4; indent-tabs-mode:nil -*- */
/*
 * Copyright (c) 2020-2026 Triad National Security, LLC
 *                         All rights reserved.
 *
 * Copyright (c) 2020-2021 Lawrence Livermore National Security, LLC
 *                         All rights reserved.
 *
 * This file is part of the quo-vadis project. See the LICENSE file at the
 * top-level directory of this distribution.
 */

/**
 * @file qvi-rmi.cc
 *
 * Resource Management and Inquiry
 */

#include "qvi-rmi.h"

// So spdlog can print values in the qvi_rmi_rpc_fid_t enum.
constexpr auto
format_as(
    qvi_rmi_rpc_fid_t e
) {
    return fmt::underlying(e);
}

// Indicates whether the server has been signaled to shutdown.
static volatile std::sig_atomic_t g_server_shutdown_signaled(false);

struct qvi_rmi_msg_header {
    qvi_rmi_rpc_fid_t fid = QVI_RMI_FID_INVALID;
};

/**
 * Prints ZMQ error information. Defined as a macro so
 * that the line numbers correspond to the error site.
 */
#define zerr_msg(ers, erno)                                                   \
do {                                                                          \
    qvi_log_error("{} with errno={} ({})", ers, erno, strerror(erno));        \
} while (0)

/**
 * Prints ZMQ warnings. Defined as a macro so that
 * the line numbers correspond to the warning site.
 */
#define zwrn_msg(ers, erno)                                                   \
do {                                                                          \
    qvi_log_warn("{} with errno={} ({})", ers, erno, strerror(erno));         \
} while (0)

static void
server_signal_handler(
    int
) {
    g_server_shutdown_signaled = true;
}

static inline void
zsocket_close(
    void *sock
) {
    if (qvi_unlikely(!sock)) return;
    const int rc = zmq_close(sock);
    if (qvi_unlikely(rc != 0)) {
        const int eno = errno;
        zwrn_msg("zmq_close() failed", eno);
    }
}

static inline void
zctx_destroy(
    void **ctx
) {
    if (qvi_unlikely(!ctx)) return;
    void *ictx = *ctx;
    if (qvi_likely(ictx)) {
        const int rc = zmq_ctx_destroy(ictx);
        if (qvi_unlikely(rc != 0)) {
            const int eno = errno;
            zwrn_msg("zmq_ctx_destroy() failed", eno);
        }
    }
    *ctx = nullptr;
}

static inline void *
zsocket_create(
    void *zctx,
    int sock_type
) {
    void *zsock = zmq_socket(zctx, sock_type);
    if (qvi_unlikely(!zsock)) {
        const int eno = errno;
        zerr_msg("zmq_socket() failed", eno);
        return nullptr;
    }
    return zsock;
}

static inline int
zsocket_connect(
    void *zsock,
    const char *addr
) {
    const int rc = zmq_connect(zsock, addr);
    if (qvi_unlikely(rc != 0)) {
        const int eno = errno;
        zerr_msg("zmq_connect() failed", eno);
        zsocket_close(zsock);
        return QV_ERR_RPC;
    }
    return QV_SUCCESS;
}

static inline void *
zsocket_create_and_bind(
    void *zctx,
    int sock_type,
    const char *addr
) {
    void *zsock = zmq_socket(zctx, sock_type);
    if (qvi_unlikely(!zsock)) {
        const int eno = errno;
        zerr_msg("zmq_socket() failed", eno);
        return nullptr;
    }
    const int rc = zmq_bind(zsock, addr);
    if (qvi_unlikely(rc != 0)) {
        const int eno = errno;
        zerr_msg("zmq_bind() failed", eno);
        zsocket_close(zsock);
        return nullptr;
    }
    return zsock;
}

static inline int
buffer_append_header(
    qvi_bbuff *buff,
    qvi_rmi_rpc_fid_t fid
) {
    qvi_rmi_msg_header hdr;
    hdr.fid = fid;
    return buff->append(&hdr, sizeof(hdr));
}

static inline void *
data_trim(
    void *msg,
    size_t trim
) {
    byte_t *new_base = static_cast<byte_t *>(msg);
    new_base += trim;
    return new_base;
}

/**
 * Unpacks a message header from a buffer of the provided size. Guards against
 * short/truncated messages that cannot contain a full header (which would
 * otherwise cause an out-of-bounds read). On success, *hdr is populated and the
 * number of header bytes consumed is returned via *trim.
 */
static inline int
unpack_msg_header(
    void *data,
    size_t data_size,
    qvi_rmi_msg_header *hdr,
    size_t *trim
) {
    const size_t hdrsize = sizeof(*hdr);
    if (qvi_unlikely(!data || data_size < hdrsize)) {
        return QV_ERR_RPC;
    }
    memmove(hdr, data, hdrsize);
    *trim = hdrsize;
    return QV_SUCCESS;
}

static inline int
zsock_send_bbuff(
    void *zsock,
    qvi_bbuff *bbuff,
    int *bsent
) {
    const int buff_size = bbuff->size();
    *bsent = zmq_send(zsock, bbuff->data(), buff_size, 0);
    if (qvi_unlikely(*bsent != buff_size)) {
        const int eno = errno;
        zerr_msg("zmq_send() truncated", eno);
        return QV_ERR_RPC;
    }
    // We are responsible for freeing the buffer after ZMQ has
    // taken ownership of its contents after zmq_send() returns.
    qvi_delete(&bbuff);
    return QV_SUCCESS;
}

int
qvi_rmi_server::m_recv_msg(
    zmq_msg_t *mrx
) {
    int qvrc = QV_SUCCESS;

    int zrc = zmq_msg_init(mrx);
    if (qvi_unlikely(zrc != 0)) {
        const int eno = errno;
        zerr_msg("zmq_msg_init() failed", eno);
        return QV_ERR_RPC;
    }

    const int npoll_items = 1;
    zmq_pollitem_t poll_items[npoll_items] = {
        // Monitor m_zsock for incoming messages (recv).
        {m_zsock, 0, ZMQ_POLLIN, 0}
    };

    do {
        if (qvi_unlikely(g_server_shutdown_signaled)) {
            qvrc = QV_SUCCESS_SHUTDOWN;
            break;
        }
        // Poll for events with a timeout of 1000ms.
        zrc = zmq_poll(poll_items, npoll_items, 1000);
        if (qvi_unlikely(zrc == -1)) {
            const int eno = errno;
            // Poll interrupted by delivery of a signal before any events were
            // available. Continue to see if we had any new relevant signal
            // events.
            if (eno == EINTR) {
                continue;
            }
            // A real error occurred.
            else {
                zerr_msg("zmq_poll() failed", eno);
                qvrc = QV_ERR_RPC;
                break;
            }
        }
        // Timeout, no events.
        else if (zrc == 0) {
            continue;
        }
        // Events on the socket ready for receipt.
        if (poll_items[0].revents & ZMQ_POLLIN) {
            // Perform a blocking receive of the available message.
            zrc = zmq_msg_recv(mrx, m_zsock, 0);
            if (qvi_unlikely(zrc == -1)) {
                const int eno = errno;
                zerr_msg("zmq_msg_recv() failed", eno);
                qvrc = QV_ERR_RPC;
            }
            break;
        }
    } while (true);

    if (qvi_unlikely(qvrc != QV_SUCCESS)) zmq_msg_close(mrx);
    return qvrc;
}

template <typename... Types>
static inline int
rpc_pack(
    qvi_bbuff **buff,
    qvi_rmi_rpc_fid_t fid,
    Types &&...args
) {
    int rc = QV_SUCCESS;
    qvi_bbuff *ibuff = new qvi_bbuff();
    do {
        // Fill and add header.
        rc = buffer_append_header(ibuff, fid);
        if (qvi_unlikely(rc != QV_SUCCESS)) break;

        rc = ibuff->pack(std::forward<Types>(args)...);
    } while (false);

    if (qvi_unlikely(rc != QV_SUCCESS)) {
        qvi_delete(&ibuff);
    }
    *buff = ibuff;
    return rc;
}

template <typename... Types>
static inline int
rpc_unpack(
    void *data,
    size_t data_size,
    Types &&...args
) {
    qvi_rmi_msg_header hdr;
    size_t trim = 0;
    // Guard against truncated/empty replies that cannot hold a full header,
    // which would otherwise cause an out-of-bounds read in the header memmove.
    const int rc = unpack_msg_header(data, data_size, &hdr, &trim);
    if (qvi_unlikely(rc != QV_SUCCESS)) return rc;

    return qvi_bbuff::unpack(
        data_trim(data, trim),
        data_size - trim,
        std::forward<Types>(args)...
    );
}

qvi_rmi_client::~qvi_rmi_client(void)
{
    // Make sure we can safely call zmq_ctx_destroy(). Otherwise it will hang.
    if (m_connected) {
        zsocket_close(m_zsock);
        zctx_destroy(&m_zctx);
    }
}

qvi_hwloc &
qvi_rmi_client::hwloc(void)
{
    return m_hwloc;
}

int
qvi_rmi_client::discover(
    int &portno
) {
    // The discovered port is invariant for the lifetime of a process: it comes
    // either from QVI_ENV_PORT (fixed) or from an already-running daemon whose
    // port does not change. Threaded groups (e.g. OpenMP) construct one
    // qvi_task per thread, each of which calls discover() before opening its
    // own connection. Without memoization every such call re-scans all of
    // /proc, which dominated discovery hit counts in coverage/profiling.
    // Cache the resolved port so the (expensive) /proc scan runs at most once
    // per process; each thread still establishes its own connection afterward.
    static std::mutex s_mutex;
    static bool s_have_port = false;
    static int s_cached_port = QVI_PORT_UNSET;

    std::lock_guard<std::mutex> guard(s_mutex);
    if (s_have_port) {
        portno = s_cached_port;
        return QV_SUCCESS;
    }

    int rc = QV_SUCCESS;
    // If this fails, envport is set to QVI_COMM_PORT_UNSET.
    int envport = qvi_port_from_env();
    // A connection port is requested via environment variable.
    if (envport != QVI_PORT_UNSET) {
        rc = qvi_session_discover(1024, envport);
        // Found it!
        if (rc == QV_SUCCESS) {
            portno = envport;
            s_cached_port = envport;
            s_have_port = true;
            return rc;
        }
    }
    // Try to discover an arbitrary, active session.
    rc = qvi_session_discover(1024, portno);
    if (rc == QV_SUCCESS) {
        s_cached_port = portno;
        s_have_port = true;
    }
    return rc;
}

int
qvi_rmi_client::connect(
    qv_scope_flags_t scope_flags,
    const std::string &url,
    const int portno
) {
    // Create a new ZMQ context.
    m_zctx = zmq_ctx_new();
    if (qvi_unlikely(!m_zctx)) return QV_ERR_UNAVAILABLE;
    // Create the ZMQ socket used for communication with the server.
    m_zsock = zsocket_create(m_zctx, ZMQ_REQ);
    if (qvi_unlikely(!m_zsock)) return QV_ERR_UNAVAILABLE;
    // Note: ZMQ_CONNECT_TIMEOUT doesn't seem to have an appreciable effect.
    int zrc = zsocket_connect(m_zsock, url.c_str());
    if (qvi_unlikely(zrc != 0)) {
        const int eno = errno;
        zerr_msg("zsocket_connect() failed", eno);
        return QV_ERR_UNAVAILABLE;
    }
    // To avoid hangs in faulty connections, set a timeout
    // before initiating the first client/server exchange.
    const int timeout_in_ms = 5000;
    zrc = zmq_setsockopt(
        m_zsock, ZMQ_RCVTIMEO, &timeout_in_ms, sizeof(timeout_in_ms)
    );
    if (qvi_unlikely(zrc != 0)) {
        const int eno = errno;
        zerr_msg("zmq_setsockopt(ZMQ_RCVTIMEO) failed", eno);
        return QV_ERR_UNAVAILABLE;
    }
    // Now initiate the client/server exchange.
    qvi_hwloc_flags_t hwloc_flags = QVI_HWLOC_FLAG_TOPO_FULL;
    if (scope_flags & QV_SCOPE_FLAG_NO_SMT) {
        hwloc_flags = QVI_HWLOC_FLAG_TOPO_NO_SMT;
    }
    std::string hwtopo_path;
    int rc = m_hello(QVI_0xVERSION, hwloc_flags, hwtopo_path);
    if (qvi_unlikely(rc != QV_SUCCESS)) {
        return rc;
    }
    else {
        m_connected = true;
    }
    // Now that we have all the info we need,
    // finish populating the RMI config.
    m_config.portno = portno;
    m_config.url = url;
    // Now we can initialize and load our topology.
    rc = m_hwloc.topology_init(hwloc_flags, hwtopo_path);
    if (qvi_unlikely(rc != QV_SUCCESS)) return QV_ERR_UNAVAILABLE;

    rc = m_hwloc.topology_load();
    if (qvi_unlikely(rc != QV_SUCCESS)) return QV_ERR_UNAVAILABLE;

    return QV_SUCCESS;
}

int
qvi_rmi_client::m_recv_msg(
    zmq_msg_t *mrx
) const {
    int qvrc = QV_SUCCESS;

    int rc = zmq_msg_init(mrx);
    if (qvi_unlikely(rc != 0)) {
        const int eno = errno;
        zerr_msg("zmq_msg_init() failed", eno);
        return QV_ERR_RPC;
    }
    // Block until a message is available to be received from socket.
    rc = zmq_msg_recv(mrx, m_zsock, 0);
    if (qvi_unlikely(rc == -1)) {
        const int eno = errno;
        zerr_msg("zmq_msg_recv() failed", eno);
        qvrc = QV_ERR_RPC;
    }

    if (qvi_unlikely(qvrc != QV_SUCCESS)) zmq_msg_close(mrx);
    return qvrc;
}

template <typename... Types>
int
qvi_rmi_client::rpc_rep(
    Types &&...args
) const {
    int rc = QV_SUCCESS;
    zmq_msg_t msg;

    do {
        rc = m_recv_msg(&msg);
        if (qvi_unlikely(rc != QV_SUCCESS)) break;
        rc = rpc_unpack(
            zmq_msg_data(&msg), zmq_msg_size(&msg),
            std::forward<Types>(args)...
        );
    } while (false);

    zmq_msg_close(&msg);
    return rc;
}

template <typename... Types>
int
qvi_rmi_client::rpc_req(
    qvi_rmi_rpc_fid_t fid,
    Types &&...args
) const {
    qvi_bbuff *bbuff = nullptr;
    const int rc = rpc_pack(&bbuff, fid, std::forward<Types>(args)...);
    if (qvi_unlikely(rc != QV_SUCCESS)) {
        qvi_delete(&bbuff);
        return rc;
    }
    int bsent = 0;
    return zsock_send_bbuff(m_zsock, bbuff, &bsent);
}

////////////////////////////////////////////////////////////////////////////////
// Client-Side RPC Definitions
////////////////////////////////////////////////////////////////////////////////
int
qvi_rmi_client::m_hello(
    size_t client_version,
    qvi_hwloc_flags_t flags,
    std::string &hwtopo_path
) {
    int qvrc = rpc_req(QVI_RMI_FID_HELLO, client_version, flags, qvi_gettid());
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    // Should be set by rpc_rep, so assume an error.
    int rpcrc = QV_ERR_RPC;
    qvrc = rpc_rep(rpcrc, hwtopo_path);
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    return rpcrc;
}

int
qvi_rmi_client::get_cpubind(
    pid_t who,
    qvi_hwloc_bitmap &cpuset
) const {
    int qvrc = rpc_req(QVI_RMI_FID_GET_CPUBIND, m_hwloc.flags(), who);
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    // Should be set by rpc_rep, so assume an error.
    int rpcrc = QV_ERR_RPC;
    qvrc = rpc_rep(rpcrc, cpuset);
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    return rpcrc;
}

int
qvi_rmi_client::set_cpubind(
    pid_t who,
    const qvi_hwloc_bitmap &cpuset
) {
    int qvrc = rpc_req(QVI_RMI_FID_SET_CPUBIND, m_hwloc.flags(), who, cpuset);
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    // Should be set by rpc_rep, so assume an error.
    int rpcrc = QV_ERR_RPC;
    qvrc = rpc_rep(rpcrc);
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    return rpcrc;
}

int
qvi_rmi_client::get_intrinsic_hwpool(
    const std::vector<pid_t> &who,
    qv_scope_intrinsic_t iscope,
    qv_scope_flags_t flags,
    qvi_hwpool &hwpool
) {
    int qvrc = rpc_req(
        QVI_RMI_FID_GET_INTRINSIC_HWPOOL,
        m_hwloc.flags(), who, iscope, flags
    );
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    // Should be set by rpc_rep, so assume an error.
    int rpcrc = QV_ERR_RPC;
    // Get the new hardware pool.
    qvrc = rpc_rep(rpcrc, hwpool);
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    return rpcrc;
}

int
qvi_rmi_client::get_obj_depth(
    qv_hw_type_t type,
    int &depth
) {
    int qvrc = rpc_req(QVI_RMI_FID_OBJ_TYPE_DEPTH, m_hwloc.flags(), type);
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    // Should be set by rpc_rep, so assume an error.
    int rpcrc = QV_ERR_RPC;
    qvrc = rpc_rep(rpcrc, depth);
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    return rpcrc;
}

int
qvi_rmi_client::get_nobjs_in_cpuset(
    qv_hw_type_t target_obj,
    const qvi_hwloc_bitmap &cpuset,
    size_t &nobjs
) {
    int qvrc = rpc_req(
        QVI_RMI_FID_GET_NOBJS_IN_CPUSET,
        m_hwloc.flags(), target_obj, cpuset
    );
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    // Should be set by rpc_rep, so assume an error.
    int rpcrc = QV_ERR_RPC;
    qvrc = rpc_rep(rpcrc, nobjs);
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    return rpcrc;
}

int
qvi_rmi_client::get_device_in_cpuset(
    qv_hw_type_t dev_obj,
    int dev_i,
    const qvi_hwloc_bitmap &cpuset,
    qv_dev_id_type_t dev_id_type,
    std::string &dev_id
) {
    int qvrc = rpc_req(
        QVI_RMI_FID_GET_DEVICE_IN_CPUSET,
        m_hwloc.flags(), dev_obj, dev_i, cpuset, dev_id_type
    );
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    // Should be set by rpc_rep, so assume an error.
    int rpcrc = QV_ERR_RPC;
    qvrc = rpc_rep(rpcrc, dev_id);
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    return rpcrc;
}

int
qvi_rmi_client::get_cpuset_for_nobjs(
    const qvi_hwloc_bitmap &cpuset,
    qv_hw_type_t obj_type,
    int nobjs,
    qvi_hwloc_bitmap &result
) {
    int qvrc = rpc_req(
        QVI_RMI_FID_GET_CPUSET_FOR_NOBJS,
        m_hwloc.flags(), cpuset, obj_type, nobjs
    );
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    // Should be set by rpc_rep, so assume an error.
    int rpcrc = QV_ERR_RPC;
    qvrc = rpc_rep(rpcrc, result);
    if (qvi_unlikely(qvrc != QV_SUCCESS)) return qvrc;
    return rpcrc;
}

int
qvi_rmi_client::send_shutdown_message(void)
{
    return rpc_req(QVI_RMI_FID_SERVER_SHUTDOWN);
}

qvi_rmi_server::qvi_rmi_server(void)
{
    // Register signal handlers.
    struct sigaction action = {};
    action.sa_handler = server_signal_handler;

    sigaction(SIGTERM, &action, nullptr);
    sigaction(SIGINT, &action, nullptr);
    sigaction(SIGHUP, &action, nullptr);

    m_rpc_dispatch_table = {
        {QVI_RMI_FID_INVALID, s_rpc_invalid},
        {QVI_RMI_FID_SERVER_SHUTDOWN, s_rpc_shutdown},
        {QVI_RMI_FID_HELLO, s_rpc_hello},
        {QVI_RMI_FID_GET_CPUBIND, s_rpc_get_cpubind},
        {QVI_RMI_FID_SET_CPUBIND, s_rpc_set_cpubind},
        {QVI_RMI_FID_OBJ_TYPE_DEPTH, s_rpc_obj_type_depth},
        {QVI_RMI_FID_GET_NOBJS_IN_CPUSET, s_rpc_get_nobjs_in_cpuset},
        {QVI_RMI_FID_GET_CPUSET_FOR_NOBJS, s_rpc_get_cpuset_for_nobjs},
        {QVI_RMI_FID_GET_DEVICE_IN_CPUSET, s_rpc_get_device_in_cpuset},
        {QVI_RMI_FID_GET_INTRINSIC_HWPOOL, s_rpc_get_intrinsic_hwpool}
    };

    for (const auto topo_type : qvi_hwloc::topo_types()) {
        auto &hwloc = m_hwlocs.get(topo_type);

        int qvrc = hwloc.topology_init(topo_type);
        if (qvi_unlikely(qvrc != QV_SUCCESS)) {
            static cstr_t ers = "hwloc.topology_init() failed";
            qvi_log_error("{} (rc={}, {})", ers, qvrc, qv_strerr(qvrc));
            throw qvi_runtime_error(qvrc);
        }

        qvrc = hwloc.topology_load();
        if (qvi_unlikely(qvrc != QV_SUCCESS)) {
            static cstr_t ers = "hwloc.topology_load() failed";
            qvi_log_error("{} (rc={}, {})", ers, qvrc, qv_strerr(qvrc));
            throw qvi_runtime_error(qvrc);
        }
    }

    m_zctx = zmq_ctx_new();
    if (qvi_unlikely(!m_zctx)) throw qvi_runtime_error(QV_ERR_SYS);
}

qvi_rmi_server::~qvi_rmi_server(void)
{
    zsocket_close(m_zsock);
    zctx_destroy(&m_zctx);
}

bool
qvi_rmi_server::m_valid_topo_flags(
    qvi_hwloc_flags_t flags
) const {
    // Mirror the indexing used by qvi_hwlocs::get(): only the topology-type
    // bits are significant, and only the known topology types are valid.
    const qvi_hwloc_flags_t topo = flags & QVI_HWLOC_TOPO_MASK;
    for (const auto valid : qvi_hwloc::topo_types()) {
        if (topo == valid) return true;
    }
    return false;
}

int
qvi_rmi_server::m_get_iscope_bitmap_system(
    qvi_hwloc_flags_t flags,
    qvi_hwloc_bitmap &bitmap
) {
    // Include all system resources, even those disallowed by mechanisms such as
    // Linux cgroups. The topology is loaded with
    // HWLOC_TOPOLOGY_FLAG_INCLUDE_DISALLOWED, so the whole-system cpuset is
    // available here.
    bitmap = std::move(m_hwlocs.get(flags).topology_get_system_cpuset());
    return QV_SUCCESS;
}

int
qvi_rmi_server::m_get_iscope_bitmap_user(
    qvi_hwloc_flags_t flags,
    qvi_hwloc_bitmap &bitmap
) {
    bitmap = std::move(m_hwlocs.get(flags).topology_get_cpuset());
    return QV_SUCCESS;
}

int
qvi_rmi_server::m_get_iscope_bitmap_job(
    qvi_hwloc_flags_t flags,
    const std::vector<pid_t> &who,
    qvi_hwloc_bitmap &bitmap
) {
    int rc = QV_SUCCESS;
    const size_t nmembers = who.size();

    std::vector<qvi_hwloc_bitmap> bitmaps(nmembers);
    for (size_t i = 0; i < nmembers; ++i) {
        rc = m_hwlocs.get(flags).task_get_cpubind(who[i], bitmaps[i]);
        if (qvi_unlikely(rc != QV_SUCCESS)) break;
    }
    if (qvi_unlikely(rc != QV_SUCCESS)) return rc;

    bitmap = std::move(qvi_hwloc_bitmap::op_or(bitmaps));

    return QV_SUCCESS;
}

int
qvi_rmi_server::m_get_iscope_bitmap_proc(
    qvi_hwloc_flags_t flags,
    const std::vector<pid_t> &who,
    qvi_hwloc_bitmap &bitmap
) {
    // A process-scope request must name exactly one task. Since the request
    // arrives over the wire from a (possibly buggy or hostile) client, treat a
    // malformed 'who' as an invalid argument rather than aborting the daemon.
    if (qvi_unlikely(who.size() != 1)) return QV_ERR_INVLD_ARG;
    return m_hwlocs.get(flags).task_get_cpubind(who[0], bitmap);
}

int
qvi_rmi_server::s_rpc_get_intrinsic_hwpool(
    qvi_rmi_server *server,
    qvi_rmi_msg_header *hdr,
    void *input,
    size_t input_size,
    qvi_bbuff **output
) {
    int rpcrc = QV_SUCCESS;
    // Bitmap that encodes available host resources.
    qvi_hwloc_bitmap sbitmap;
    qvi_hwpool hwpool;

    do {
        qvi_hwloc_flags_t hwloc_flags;
        std::vector<pid_t> who;
        qv_scope_intrinsic_t iscope = {};
        qv_scope_flags_t scope_flags;
        rpcrc = qvi_bbuff::unpack(
            input, input_size, hwloc_flags, who, iscope, scope_flags
        );
        // Drop the message. Send an empty hardware pool with the error code.
        if (qvi_unlikely(rpcrc != QV_SUCCESS)) break;
        // Validate wire-supplied flags before indexing into m_hwlocs.
        if (qvi_unlikely(!server->m_valid_topo_flags(hwloc_flags))) {
            rpcrc = QV_ERR_INVLD_ARG;
            break;
        }

        switch (iscope) {
            case QV_SCOPE_SYSTEM:
                rpcrc = server->m_get_iscope_bitmap_system(hwloc_flags, sbitmap);
                break;
            case QV_SCOPE_USER:
                rpcrc = server->m_get_iscope_bitmap_user(hwloc_flags, sbitmap);
                break;
            case QV_SCOPE_JOB:
                rpcrc = server->m_get_iscope_bitmap_job(hwloc_flags, who, sbitmap);
                break;
            case QV_SCOPE_PROCESS:
                rpcrc = server->m_get_iscope_bitmap_proc(hwloc_flags, who, sbitmap);
                break;
            [[unlikely]] default:
                rpcrc = QV_ERR_INVLD_ARG;
                break;
        }
        if (qvi_unlikely(rpcrc != QV_SUCCESS)) break;
        rpcrc = hwpool.populate(server->m_hwlocs.get(hwloc_flags), sbitmap);
    } while (false);

    return rpc_pack(output, hdr->fid, rpcrc, hwpool);
}

////////////////////////////////////////////////////////////////////////////////
// Server-Side RPC Definitions
////////////////////////////////////////////////////////////////////////////////
int
qvi_rmi_server::s_rpc_invalid(
    qvi_rmi_server *,
    qvi_rmi_msg_header *hdr,
    void *,
    size_t,
    qvi_bbuff **output
) {
    // A client sent a request with the reserved invalid function ID. This is a
    // malformed request, not an internal error, so we must not abort the whole
    // daemon. Send back an error-coded reply and keep serving.
    qvi_log_warn("Received RPC with invalid function ID. Ignoring.");
    return rpc_pack(output, hdr->fid, QV_ERR_RPC);
}

int
qvi_rmi_server::s_rpc_shutdown(
    qvi_rmi_server *,
    qvi_rmi_msg_header *hdr,
    void *,
    size_t,
    qvi_bbuff **output
) {
    (void)rpc_pack(output, hdr->fid);
    return QV_SUCCESS_SHUTDOWN;
}

int
qvi_rmi_server::s_rpc_hello(
    qvi_rmi_server *server,
    qvi_rmi_msg_header *hdr,
    void *input,
    size_t input_size,
    qvi_bbuff **output
) {
    const size_t server_version = QVI_0xVERSION;
    int rpcrc = QV_SUCCESS;

    size_t client_version = 0;
    qvi_hwloc_flags_t flags = QVI_HWLOC_FLAG_TOPO_FULL;
    pid_t whoisit;
    const int rc = qvi_bbuff::unpack(
        input, input_size, client_version, flags, whoisit
    );
    // On a malformed request, reply with the error and a valid (default)
    // topology file rather than dereferencing uninitialized 'flags'.
    if (qvi_unlikely(rc != QV_SUCCESS)) {
        return rpc_pack(
            output, hdr->fid, rc,
            server->m_hwlocs.get(QVI_HWLOC_FLAG_TOPO_FULL).topology_file()
        );
    }
    // Validate the requested topology flags before using them to index into
    // m_hwlocs, which would otherwise abort on an unrecognized value.
    if (qvi_unlikely(!server->m_valid_topo_flags(flags))) {
        return rpc_pack(
            output, hdr->fid, QV_ERR_INVLD_ARG,
            server->m_hwlocs.get(QVI_HWLOC_FLAG_TOPO_FULL).topology_file()
        );
    }
    // Pack relevant configuration information.
    // We are overly protective here for now. Insist the
    // client and server share the exact same release version.
    if (qvi_unlikely(server_version != client_version)) {
        rpcrc = QV_ERR_NOT_SUPPORTED;
    }
    return rpc_pack(
        output, hdr->fid, rpcrc,
        server->m_hwlocs.get(flags).topology_file()
    );
}

int
qvi_rmi_server::s_rpc_get_cpubind(
    qvi_rmi_server *server,
    qvi_rmi_msg_header *hdr,
    void *input,
    size_t input_size,
    qvi_bbuff **output
) {
    int rpcrc = QV_SUCCESS;
    qvi_hwloc_bitmap bitmap;

    do {
        qvi_hwloc_flags_t flags;
        pid_t who;
        const int qvrc = qvi_bbuff::unpack(input, input_size, flags, who);
        if (qvi_unlikely(qvrc != QV_SUCCESS)) {
            rpcrc = qvrc;
            break;
        }
        if (qvi_unlikely(!server->m_valid_topo_flags(flags))) {
            rpcrc = QV_ERR_INVLD_ARG;
            break;
        }
        rpcrc = server->m_hwlocs.get(flags).task_get_cpubind(who, bitmap);
    } while (false);

    return rpc_pack(output, hdr->fid, rpcrc, bitmap);
}

int
qvi_rmi_server::s_rpc_set_cpubind(
    qvi_rmi_server *server,
    qvi_rmi_msg_header *hdr,
    void *input,
    size_t input_size,
    qvi_bbuff **output
) {
    int rpcrc = QV_SUCCESS;

    do {
        qvi_hwloc_flags_t flags;
        pid_t who;
        qvi_hwloc_bitmap cpuset;
        const int qvrc = qvi_bbuff::unpack(
            input, input_size, flags, who, cpuset
        );
        if (qvi_unlikely(qvrc != QV_SUCCESS)) {
            rpcrc = qvrc;
            break;
        }
        if (qvi_unlikely(!server->m_valid_topo_flags(flags))) {
            rpcrc = QV_ERR_INVLD_ARG;
            break;
        }
        rpcrc = server->m_hwlocs.get(flags).task_set_cpubind_from_cpuset(
            who, cpuset.cdata()
        );
    } while (false);

    return rpc_pack(output, hdr->fid, rpcrc);
}

int
qvi_rmi_server::s_rpc_obj_type_depth(
    qvi_rmi_server *server,
    qvi_rmi_msg_header *hdr,
    void *input,
    size_t input_size,
    qvi_bbuff **output
) {
    int rpcrc = QV_SUCCESS;
    int depth = 0;

    do {
        qvi_hwloc_flags_t flags;
        qv_hw_type_t obj;
        const int qvrc = qvi_bbuff::unpack(input, input_size, flags, obj);
        if (qvi_unlikely(qvrc != QV_SUCCESS)) {
            rpcrc = qvrc;
            break;
        }
        if (qvi_unlikely(!server->m_valid_topo_flags(flags))) {
            rpcrc = QV_ERR_INVLD_ARG;
            break;
        }
        rpcrc = server->m_hwlocs.get(flags).obj_type_depth(obj, &depth);
    } while (false);

    return rpc_pack(output, hdr->fid, rpcrc, depth);
}

int
qvi_rmi_server::s_rpc_get_nobjs_in_cpuset(
    qvi_rmi_server *server,
    qvi_rmi_msg_header *hdr,
    void *input,
    size_t input_size,
    qvi_bbuff **output
) {
    int rpcrc = QV_SUCCESS;
    size_t nobjs = 0;

    do {
        qvi_hwloc_flags_t flags;
        qv_hw_type_t target_obj;
        qvi_hwloc_bitmap cpuset;
        const int qvrc = qvi_bbuff::unpack(
            input, input_size, flags, target_obj, cpuset
        );
        if (qvi_unlikely(qvrc != QV_SUCCESS)) {
            rpcrc = qvrc;
            break;
        }
        if (qvi_unlikely(!server->m_valid_topo_flags(flags))) {
            rpcrc = QV_ERR_INVLD_ARG;
            break;
        }
        rpcrc = server->m_hwlocs.get(flags).get_nobjs_in_cpuset(
            target_obj, cpuset.cdata(), nobjs
        );
    } while (false);

    return rpc_pack(output, hdr->fid, rpcrc, nobjs);
}

int
qvi_rmi_server::s_rpc_get_cpuset_for_nobjs(
    qvi_rmi_server *server,
    qvi_rmi_msg_header *hdr,
    void *input,
    size_t input_size,
    qvi_bbuff **output
) {
    int rpcrc = QV_SUCCESS;
    qvi_hwloc_bitmap result;

    do {
        qvi_hwloc_flags_t flags;
        qvi_hwloc_bitmap cpuset;
        qv_hw_type_t obj_type;
        int nobjs;
        const int qvrc = qvi_bbuff::unpack(
            input, input_size, flags, cpuset, obj_type, nobjs
        );
        if (qvi_unlikely(qvrc != QV_SUCCESS)) {
            rpcrc = qvrc;
            break;
        }
        if (qvi_unlikely(!server->m_valid_topo_flags(flags))) {
            rpcrc = QV_ERR_INVLD_ARG;
            break;
        }
        rpcrc = server->m_hwlocs.get(flags).get_cpuset_for_nobjs(
            cpuset, obj_type, nobjs, result
        );
    } while (false);

    return rpc_pack(output, hdr->fid, rpcrc, result);
}

int
qvi_rmi_server::s_rpc_get_device_in_cpuset(
    qvi_rmi_server *server,
    qvi_rmi_msg_header *hdr,
    void *input,
    size_t input_size,
    qvi_bbuff **output
) {
    int rpcrc = QV_SUCCESS;
    std::string dev_id;

    do {
        qvi_hwloc_flags_t flags;
        qv_hw_type_t dev_obj;
        int dev_i;
        qvi_hwloc_bitmap cpuset;
        qv_dev_id_type_t devid_type;
        const int qvrc = qvi_bbuff::unpack(
            input, input_size, flags, dev_obj, dev_i, cpuset, devid_type
        );
        if (qvi_unlikely(qvrc != QV_SUCCESS)) {
            rpcrc = qvrc;
            break;
        }
        if (qvi_unlikely(!server->m_valid_topo_flags(flags))) {
            rpcrc = QV_ERR_INVLD_ARG;
            break;
        }
        rpcrc = server->m_hwlocs.get(flags).get_device_id_in_cpuset(
            dev_obj, dev_i, cpuset.cdata(), devid_type, dev_id
        );
    } while (false);

    return rpc_pack(output, hdr->fid, rpcrc, dev_id);
}

int
qvi_rmi_server::m_rpc_dispatch(
    void *zsock,
    zmq_msg_t *command_msg,
    int *bsent
) {
    int rc = QV_SUCCESS;
    bool shutdown = false;
    // The reply that will be sent back to the client. A ZMQ REP socket must
    // send exactly one reply for every request it receives; failing to do so
    // wedges the REQ/REP state machine and hangs the next client. So for every
    // request we receive we are careful to always produce some reply.
    qvi_bbuff *result = nullptr;

    do {
        void *const data = zmq_msg_data(command_msg);
        const size_t data_size = zmq_msg_size(command_msg);

        qvi_rmi_msg_header hdr;
        size_t trim = 0;
        // Guard against truncated/empty messages that cannot hold a header.
        const int mrc = unpack_msg_header(data, data_size, &hdr, &trim);
        if (qvi_unlikely(mrc != QV_SUCCESS)) {
            qvi_log_warn(
                "Dropping malformed RPC message (size={}).", data_size
            );
            // Reply with an error so the client (and REP socket) stay sane.
            rc = rpc_pack(&result, QVI_RMI_FID_INVALID, QV_ERR_RPC);
            break;
        }
        void *const body = data_trim(data, trim);
        const size_t body_size = data_size - trim;

        const auto fidfunp = m_rpc_dispatch_table.find(hdr.fid);
        if (qvi_unlikely(fidfunp == m_rpc_dispatch_table.end())) {
            qvi_log_warn(
                "Unknown function ID ({}) in RPC. Ignoring.", hdr.fid
            );
            // Reply with an error rather than dropping the message, which would
            // otherwise leave the REP socket waiting to send a reply forever.
            rc = rpc_pack(&result, QVI_RMI_FID_INVALID, QV_ERR_RPC);
            break;
        }
        // Invoke the handler. The status here reflects the server-side
        // machinery (e.g., could we build a reply?), NOT the target operation's
        // result, which the handler packs into the reply buffer for the client.
        rc = fidfunp->second(this, &hdr, body, body_size, &result);
        // A shutdown request is signaled via QV_SUCCESS_SHUTDOWN; the handler
        // still produces a valid reply that we must deliver below.
        if (qvi_unlikely(rc == QV_SUCCESS_SHUTDOWN)) {
            shutdown = true;
            rc = QV_SUCCESS;
        }
        // If the handler itself failed to produce a reply, there is nothing
        // sensible to send. Synthesize a minimal error reply so we honor the
        // REQ/REP contract and keep the server alive.
        else if (qvi_unlikely(rc != QV_SUCCESS)) {
            qvi_log_warn(
                "RPC handler for FID {} failed with rc={} ({}).",
                hdr.fid, rc, qv_strerr(rc)
            );
            qvi_delete(&result);
            rc = rpc_pack(&result, hdr.fid, QV_ERR_RPC);
        }
    } while (false);
    // Send whatever reply we produced. A failure here is a genuine transport
    // error and is treated as fatal by the caller.
    if (qvi_likely(rc == QV_SUCCESS && result)) {
        rc = zsock_send_bbuff(zsock, result, bsent);
    }
    else {
        // We could not even build a reply (e.g., OOM while packing). Clean up;
        // *bsent stays untouched/zero. This is treated as a transport-level
        // failure by the caller.
        *bsent = 0;
        qvi_delete(&result);
        if (rc == QV_SUCCESS) rc = QV_ERR_RPC;
    }

    zmq_msg_close(command_msg);
    return (shutdown ? QV_SUCCESS_SHUTDOWN : rc);
}

int
qvi_rmi_server::m_enter_main_server_loop(void)
{
    int rc, bsent;
    int bsentt = 0;
    zmq_msg_t mrx;
    do {
        rc = m_recv_msg(&mrx);
        if (qvi_unlikely(rc != QV_SUCCESS)) break;
        rc = m_rpc_dispatch(m_zsock, &mrx, &bsent);
        if (qvi_likely(rc == QV_SUCCESS)) bsentt += bsent;
        else break;
    } while(true);

    // Nice to understand messaging characteristics.
    qvi_log_info("Server Sent {} bytes", bsentt);

    if (qvi_unlikely(rc != QV_SUCCESS && rc != QV_SUCCESS_SHUTDOWN)) {
        qvi_log_error("RX/TX loop exited with rc={} ({})", rc, qv_strerr(rc));
        return rc;
    }
    return QV_SUCCESS;
}

int
qvi_rmi_server::configure(
    const qvi_rmi_config &config
) {
    m_config = config;
    return QV_SUCCESS;
}

int
qvi_rmi_server::topology_export(
    const std::string &base_path
) {
    for (const auto topo_type : qvi_hwloc::topo_types()) {
        auto &hwloc = m_hwlocs.get(topo_type);
        const int rc = hwloc.topology_export(base_path);
        if (qvi_unlikely(rc != QV_SUCCESS)) return rc;
    }
    return QV_SUCCESS;
}

int
qvi_rmi_server::start(void)
{
    // Setup our connection.
    m_zsock = zsocket_create_and_bind(
        m_zctx, ZMQ_REP, m_config.url.c_str()
    );
    if (qvi_unlikely(!m_zsock)) return QV_ERR_SYS;
    // Set linger period to 0 so clients won't hang when a server shutdown
    // request is handled. A value of 0 means the following: pending messages
    // shall be discarded immediately when the socket is closed.
    const int linger = 0;
    const int zrc = zmq_setsockopt(
        m_zsock, ZMQ_LINGER, &linger, sizeof(linger)
    );
    if (qvi_unlikely(zrc != 0)) {
        const int eno = errno;
        zerr_msg("zmq_setsockopt(ZMQ_LINGER) failed", eno);
        return QV_ERR_SYS;
    }
    // Start the main service loop.
    return m_enter_main_server_loop();
}

int
qvi_rmi_get_url(
    std::string &url,
    int &portno
) {
    static const std::string base = "tcp://127.0.0.1";

    if (portno == QVI_PORT_UNSET) {
        portno = qvi_port_from_env();
        if (portno == QVI_PORT_UNSET) return QV_ERR_ENV;
    }

    url = base + ":" + std::to_string(portno);
    return QV_SUCCESS;
}

std::string
qvi_rmi_conn_env_ers(void)
{
    return qvi_sbanner(
        "Cannot determine connection information. Try setting the "
        "following environment variable to an unused port number: " +
        QVI_ENV_PORT + "", qvi_maxolen
    );
}

std::string
qvi_rmi_discovery_ers(void)
{
    const std::string tids = std::to_string(qvi_gettid());

    return qvi_sbanner(
        "A client could not determine its connection "
        "information. PID: " + tids + "", qvi_maxolen
    );
}

/*
 * vim: ft=cpp ts=4 sts=4 sw=4 expandtab
 */
