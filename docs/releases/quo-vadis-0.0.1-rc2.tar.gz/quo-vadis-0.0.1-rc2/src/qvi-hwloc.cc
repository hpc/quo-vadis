/* -*- Mode: C++; c-basic-offset:4; indent-tabs-mode:nil -*- */
/*
 * Copyright (c) 2020-2026 Triad National Security, LLC
 *                         All rights reserved.
 *
 * Copyright (c) 2020-2021 Lawrence Livermore National Security, LLC
 *                         All rights reserved.
 *
 * This file is part of the quo-vadis project. See the LICENSE file at the
 * top-level directory of this distribution.
 */

/**
 * @file qvi-hwloc.cc
 */

#include "qvi-hwloc.h"
#include "qvi-utils.h"

/**
 * Note: we don't honor environment variables such as CUDA_VISIBLE_DEVICES,
 * ROCR_VISIBLE_DEVICES, etc.
 */

static inline const qvi_hwloc_dev_list &
cget_dev_list(
    const qvi_hwloc_dev_map &map,
    qv_hw_type_t type
) {
    static const qvi_hwloc_dev_list empty_list;

    const auto got = map.find(type);
    if (got == map.end()) return empty_list;
    return got->second;
}

hwloc_obj_type_t
qvi_hwloc::obj_get_type(
    qv_hw_type_t external
) {
    switch (external) {
        case(QV_HW_MACHINE):
            return HWLOC_OBJ_MACHINE;
        case(QV_HW_PACKAGE):
            return HWLOC_OBJ_PACKAGE;
        case(QV_HW_CORE):
            return HWLOC_OBJ_CORE;
        case(QV_HW_PU):
            return HWLOC_OBJ_PU;
        case(QV_HW_L1CACHE):
            return HWLOC_OBJ_L1CACHE;
        case(QV_HW_L2CACHE):
            return HWLOC_OBJ_L2CACHE;
        case(QV_HW_L3CACHE):
            return HWLOC_OBJ_L3CACHE;
        case(QV_HW_L4CACHE):
            return HWLOC_OBJ_L4CACHE;
        case(QV_HW_L5CACHE):
            return HWLOC_OBJ_L5CACHE;
        case(QV_HW_NUMANODE):
            return HWLOC_OBJ_NUMANODE;
        case(QV_HW_GPU):
            return HWLOC_OBJ_OS_DEVICE;
        case(QV_HW_NIC):
            return HWLOC_OBJ_OS_DEVICE;
        [[unlikely]] default:
            // This is likely an internal development error.
            throw qvi_runtime_error(QV_ERR_INTERNAL);
    }
}

/**
 * Get the numeric ID of a device name, e.g.,
 * rsmi2 -> 2
 * opencl1d0 -> 10
 * mlx5_0 -> 50
 */
static int
get_dev_id_from_name(
    const std::string &name
) {
    std::string nums = {};

    for (size_t i = 0; i < name.length(); ++i) {
        if (isdigit(name[i])) nums += name[i];
    }

    if (!nums.empty()) return qvi_stoi(nums, 10);
    return qvi_hwloc_device::INVALID_ID;
}

/**
 * Returns whether an input object has the given subtype.
 */
static inline bool
obj_has_subtype(
    hwloc_obj_t obj,
    const std::string &subtype
) {
    if (obj->subtype && !strcmp(obj->subtype, subtype.c_str())) return true;
    return false;
}

/**
 * Filters OS devices of interest and avoid duplicates.
 *
 * Devices of interest:
 * (1) GPU-type device (includes AMD-RSMI and NVIDIA-NVML)
 * (2) OPENFABRICS-type device (includes InfiniBand)
 * (3) COPROC-type: LevelZero device
 * (4) NETWORK-type (includes Slingshot and BXI devices)
 *
 * Exclude CUDA and OpenCL COPROC devices to avoid
 * duplication with NVML and RSMI devices.
 */
static inline bool
keep_os_device(
    hwloc_obj_t obj
) {
    switch (obj->attr->osdev.type) {
#ifdef QV_GPU_SUPPORT
        case HWLOC_OBJ_OSDEV_GPU:
            return true;
        case HWLOC_OBJ_OSDEV_COPROC:
            return obj_has_subtype(obj, "LevelZero");
#endif
        case HWLOC_OBJ_OSDEV_OPENFABRICS:
            return true;
        case HWLOC_OBJ_OSDEV_NETWORK:
            if (obj_has_subtype(obj, "BXI")) {
                return true;
            }
            else if (obj_has_subtype(obj, "Slingshot")) {
                // Keep the CXI (Cassini) interfaces. libfabric uses the CXI
                // provider to drive the Slingshot network. Linux, on the other
                // hand, uses the HSI interfaces (TCP).
                int n;
                if (sscanf(obj->name, "cxi%d", &n) == 1) return true;
                else return false;
            }
            else {
                return false;
            }
        default:
            return false;
    }
}

static std::string
get_obj_info_by_name(
    hwloc_obj_t obj,
    const std::string &name
) {
    if (name.empty()) return {};
    const char *maybe_info = hwloc_obj_get_info_by_name(obj, name.c_str());
    if (!maybe_info) return {};
    return maybe_info;
}

qvi_hwloc_res_class
qvi_hwloc::obj_res_class(
    qv_hw_type_t type
) {
    switch (type) {
        case(QV_HW_MACHINE):
        case(QV_HW_PACKAGE):
        case(QV_HW_CORE):
        case(QV_HW_PU):
        case(QV_HW_L1CACHE):
        case(QV_HW_L2CACHE):
        case(QV_HW_L3CACHE):
        case(QV_HW_L4CACHE):
        case(QV_HW_L5CACHE):
        case(QV_HW_NUMANODE):
            return QVI_HWLOC_RES_CLASS_HOST;
        case(QV_HW_GPU):
        case(QV_HW_NIC):
            return QVI_HWLOC_RES_CLASS_DEV;
        case(QV_HW_LAST):
            return QVI_HWLOC_RES_CLASS_LAST;
        [[unlikely]] default:
            // This is likely an internal development error.
            throw qvi_runtime_error(QV_ERR_INTERNAL);
    }
}

/**
 * Returns a pointer to the associated PCI object, nullptr otherwise.
 */
static inline hwloc_obj_t
get_pci_obj(
    hwloc_obj_t dev
) {
    if (dev->type == HWLOC_OBJ_PCI_DEVICE) return dev;
    if (dev->parent->type == HWLOC_OBJ_PCI_DEVICE) return dev->parent;
    return nullptr;
}

/**
 * If available, returns the PCI information of the input device. Returns a
 * [pci_obj, string] tuple, [nullptr, ""] otherwise.
 */
static inline std::tuple<hwloc_obj_t, std::string>
get_pci_info(
    hwloc_obj_t dev
) {
    hwloc_obj_t pcidev = get_pci_obj(dev);
    if (!pcidev) return {nullptr, ""};

    static constexpr int PCI_BUS_ID_BUFF_SIZE = 32;
    char busid_buffer[PCI_BUS_ID_BUFF_SIZE] = {'\0'};
    const int np = snprintf(
        busid_buffer, PCI_BUS_ID_BUFF_SIZE,
        "%04x:%02x:%02x.%01x",
        pcidev->attr->pcidev.domain,
        pcidev->attr->pcidev.bus,
        pcidev->attr->pcidev.dev,
        pcidev->attr->pcidev.func
    );
    if (qvi_unlikely(np >= PCI_BUS_ID_BUFF_SIZE)) {
        throw qvi_runtime_error(QV_ERR_INTERNAL);
    }
    return {pcidev, std::string(busid_buffer)};
}

static std::string
topo_fname(
    const std::string &base,
    qvi_hwloc_flags_t flags
) {
    return base + "/hwtopo." + std::to_string(getpid()) + "-"
                + std::to_string(flags) + ".xml";
}

int
qvi_hwloc::bitmap_calloc(
    hwloc_cpuset_t *cpuset
) {
    *cpuset = hwloc_bitmap_alloc();
    if (qvi_unlikely(!*cpuset)) return QV_ERR_OOR;
    hwloc_bitmap_zero(*cpuset);
    return QV_SUCCESS;
}

void
qvi_hwloc::bitmap_delete(
    hwloc_cpuset_t *cpuset
) {
    if (qvi_unlikely(!cpuset)) return;
    // If bitmap is NULL, no operation is performed, so skip double check.
    hwloc_bitmap_free(*cpuset);
    *cpuset = nullptr;
}

int
qvi_hwloc::bitmap_copy(
    hwloc_const_cpuset_t src,
    hwloc_cpuset_t dest
) {
    assert(src && dest);
    const int rc = hwloc_bitmap_copy(dest, src);
    if (qvi_unlikely(rc != 0)) {
        return QV_ERR_HWLOC;
    }
    return QV_SUCCESS;
}

int
qvi_hwloc::bitmap_dup(
    hwloc_const_cpuset_t src,
    hwloc_cpuset_t *dest
) {
    int rc = QV_SUCCESS;
    hwloc_cpuset_t idest = nullptr;
    do {
        rc = qvi_hwloc::bitmap_calloc(&idest);
        if (qvi_unlikely(rc != QV_SUCCESS)) break;

        rc = qvi_hwloc::bitmap_copy(src, idest);
    } while (false);

    if (qvi_unlikely(rc != QV_SUCCESS)) {
        qvi_hwloc::bitmap_delete(&idest);
    }
    *dest = idest;
    return rc;
}

int
qvi_hwloc_bitmap_nbits(
    hwloc_const_cpuset_t cpuset,
    size_t *nbits
) {
    *nbits = 0;

    const int inbits = hwloc_bitmap_last(cpuset);
    if (qvi_unlikely(inbits == -1)) return QV_ERR_HWLOC;

    *nbits = static_cast<size_t>(inbits) + 1;
    return QV_SUCCESS;
}

std::string
qvi_hwloc::bitmap_string(
    const qvi_hwloc_bitmap &bitmap
) {
    char *iresult = nullptr;
    (void)hwloc_bitmap_asprintf(&iresult, bitmap.cdata());
    if (qvi_unlikely(!iresult)) throw qvi_runtime_error(QV_ERR_OOR);

    std::string result(iresult);
    free(iresult);
    return result;
}

std::string
qvi_hwloc::bitmap_list_string(
    hwloc_const_cpuset_t cpuset
) {
    char *iresult = nullptr;
    (void)hwloc_bitmap_list_asprintf(&iresult, cpuset);
    if (qvi_unlikely(!iresult)) throw qvi_runtime_error(QV_ERR_OOR);

    std::string result(iresult);
    free(iresult);
    return result;
}

int
qvi_hwloc::bitmap_sscanf(
    hwloc_cpuset_t cpuset,
    char *str
) {
    const int rc = hwloc_bitmap_sscanf(cpuset, str);
    if (qvi_unlikely(rc != 0)) {
        return QV_ERR_HWLOC;
    }
    return QV_SUCCESS;
}

std::vector<qvi_hwloc_bitmap>
qvi_hwloc::bitmap_split(
    const qvi_hwloc_bitmap &bitmap,
    size_t npieces
) const {
    size_t npus = 0;
    int rc = m_get_nobjs_in_cpuset(
        QV_HW_PU, bitmap.cdata(), npus
    );
    if (qvi_unlikely(rc != QV_SUCCESS)) throw qvi_runtime_error(rc);
    // An empty split.
    std::vector<qvi_hwloc_bitmap> result;
    if (qvi_unlikely(npieces == 0 || npus == 0 || npieces > npus)) {
        return result;
    }
    // We split the resources by distributing npieces cpusets over the topology
    // subtree(s) spanned by the given cpuset. Rather than partitioning PUs in
    // flat logical-index order, we defer to hwloc_distrib(), which recursively
    // distributes the pieces linearly over the topology. This respects the
    // hardware hierarchy (Cores, caches, NUMA boundaries) so that each piece
    // tends to keep its PUs local, mirroring the topology-aware distribution
    // used by tools like mpibind.
    //
    // Note: on hybrid/asymmetric platforms (e.g. mixed P-/E-cores, or an
    // uneven number of cores below packages/caches) hwloc's top-down recursive
    // partitioning may be suboptimal because it ignores per-subtree object
    // counts until it reaches their levels. See the hwloc_distrib()
    // documentation in hwloc/helper.h for details.
    //
    // hwloc_distrib() requires root objects that have a CPU set. Since the
    // given cpuset is generally an arbitrary union (a subset of the machine),
    // build the set of largest topology objects tiling the cpuset and use them
    // as the distribution roots so we only distribute over the pool's actual
    // resources.
    std::vector<hwloc_obj_t> roots;
    {
        qvi_hwloc_bitmap remaining(bitmap.cdata());
        while (!hwloc_bitmap_iszero(remaining.cdata())) {
            hwloc_obj_t obj = hwloc_get_first_largest_obj_inside_cpuset(
                m_topo, remaining.cdata()
            );
            if (qvi_unlikely(!obj || !obj->cpuset)) {
                // Should not happen for a valid, non-empty cpuset.
                return result;
            }
            roots.push_back(obj);
            // Clear this object's PUs from the remaining work set.
            const int arc = hwloc_bitmap_andnot(
                remaining.data(), remaining.cdata(), obj->cpuset
            );
            if (qvi_unlikely(arc != 0)) return result;
        }
    }
    if (qvi_unlikely(roots.empty())) return result;
    // Prepare for storing non-empty split.
    result.resize(npieces);
    // hwloc_distrib() allocates a fresh cpuset for each of the npieces slots
    // and stores the new pointers into this array; the caller owns and must
    // free them. It does not fill caller-provided bitmaps.
    std::vector<hwloc_cpuset_t> sets(npieces, nullptr);
    // Distribute npieces over the roots, down to the finest level.
    rc = hwloc_distrib(
        m_topo, roots.data(), static_cast<unsigned>(roots.size()),
        sets.data(), static_cast<unsigned>(npieces), INT_MAX, 0
    );
    if (qvi_unlikely(rc != 0)) {
        for (auto &s : sets) if (s) hwloc_bitmap_free(s);
        result.clear();
        return result;
    }
    // Copy each distributed cpuset into the result, clamping to the input
    // cpuset. The roots are included in the input cpuset, so hwloc_distrib()
    // stays within it; this and is defensive to guarantee no piece ever exceeds
    // the pool's resources. Free hwloc's allocations as we go.
    for (size_t i = 0; i < npieces; ++i) {
        int arc = 0;
        if (sets[i]) {
            arc = hwloc_bitmap_and(
                result[i].data(), sets[i], bitmap.cdata()
            );
            hwloc_bitmap_free(sets[i]);
            sets[i] = nullptr;
        }
        if (qvi_unlikely(arc != 0)) {
            for (auto &s : sets) if (s) hwloc_bitmap_free(s);
            result.clear();
            return result;
        }
    }
    return result;
}

qvi_hwloc::~qvi_hwloc(void)
{
    if (m_topo) hwloc_topology_destroy(m_topo);
    // Unlink the file if we exported it.
    if (!(m_flags & QVI_HWLOC_FLAG_TOPO_XML)) {
        unlink(m_topo_file.c_str());
    }
}

int
qvi_hwloc::m_topo_set_from_xml(
    const std::string &path
) {
    // Note that this topology was loaded from an XML file.
    m_flags |= QVI_HWLOC_FLAG_TOPO_XML;

    const int rc = hwloc_topology_set_xml(m_topo, path.c_str());
    if (qvi_unlikely(rc == -1)) {
        qvi_log_error("hwloc_topology_set_xml() failed");
        return QV_ERR_HWLOC;
    }
    return QV_SUCCESS;
}

int
qvi_hwloc::topology_init(
    qvi_hwloc_flags_t flags,
    const std::string &xml_path
) {
    // Cache the provided flags that influence our behavior.
    m_flags = flags;

    const int rc = hwloc_topology_init(&m_topo);
    if (qvi_unlikely(rc != 0)) {
        qvi_log_error("hwloc_topology_init() failed");
        return QV_ERR_HWLOC;
    }

    if (!xml_path.empty()) return m_topo_set_from_xml(xml_path);
    return QV_SUCCESS;
}

int
qvi_hwloc::topology_load(void)
{
    int rc = QV_SUCCESS;
    cstr_t ers = nullptr;
    do {
        // Set flags that influence hwloc's behavior. Include resources that are
        // not allowed (e.g., by cgroups) in the base topology. We will have
        // functions that provide bitmap access to allowed and disallowed
        // resources depending on need, but we must load it all.
        const uint_t hwloc_flags = HWLOC_TOPOLOGY_FLAG_INCLUDE_DISALLOWED;
        rc = hwloc_topology_set_flags(m_topo, hwloc_flags);
        if (qvi_unlikely(rc != 0)) {
            ers = "hwloc_topology_set_flags() failed";
            rc = QV_ERR_HWLOC;
            break;
        }

        rc = hwloc_topology_set_all_types_filter(
            m_topo, HWLOC_TYPE_FILTER_KEEP_IMPORTANT
        );
        if (qvi_unlikely(rc != 0)) {
            ers = "hwloc_topology_set_all_types_filter() failed";
            rc = QV_ERR_HWLOC;
            break;
        }

        rc = hwloc_topology_set_type_filter(
            m_topo,
            HWLOC_OBJ_OS_DEVICE,
            HWLOC_TYPE_FILTER_KEEP_IMPORTANT
        );
        if (qvi_unlikely(rc != 0)) {
            ers = "hwloc_topology_set_type_filter() failed";
            rc = QV_ERR_HWLOC;
            break;
        }

        rc = hwloc_topology_load(m_topo);
        if (qvi_unlikely(rc != 0)) {
            ers = "hwloc_topology_load() failed";
            rc = QV_ERR_HWLOC;
            break;
        }

        if (m_flags & QVI_HWLOC_FLAG_TOPO_NO_SMT &&
            !(m_flags & QVI_HWLOC_FLAG_TOPO_XML)) {
            rc = m_disable_smt();
            if (qvi_unlikely(rc != QV_SUCCESS)) {
                ers = "m_disable_smt() failed";
                break;
            }
        }

        rc = m_discover_devices();
        if (qvi_unlikely(rc != QV_SUCCESS)) {
            ers = "m_discover_devices() failed";
        }
    } while (false);

    if (qvi_unlikely(ers)) {
        qvi_log_error("{} with rc={} ({})", ers, rc, qv_strerr(rc));
    }
    return rc;
}

/**
 *
 */
int
qvi_hwloc::s_topo_fopen(
    const std::string &path,
    int *fd
) {
    const int ifd = open(path.c_str(), O_CREAT | O_RDWR, 0644);
    if (qvi_unlikely(ifd == -1)) {
        const int err = errno;
        cstr_t ers = "open() failed";
        qvi_log_error("{} {}", ers, strerror(err));
        return QV_ERR_FILE_IO;
    }
    // We need to publish this file to consumers that are potentially not part
    // of our group. We cannot assume the current umask, so set explicitly.
    const int rc = fchmod(ifd, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
    if (qvi_unlikely(rc == -1)) {
        const int err = errno;
        cstr_t ers = "fchmod() failed";
        qvi_log_error("{} {}", ers, strerror(err));
        return QV_ERR_FILE_IO;
    }
    *fd = ifd;
    return QV_SUCCESS;
}

int
qvi_hwloc::topology_export(
    const std::string &base_path
) {
    int qvrc = QV_SUCCESS, rc = 0, fd = 0;
    cstr_t ers = nullptr;
    char *topo_xml = nullptr;

    do {
        int err = 0;
        const bool usable = qvi_access(base_path, R_OK | W_OK, &err);
        if (qvi_unlikely(!usable)) {
            qvi_log_error(
                "Cannot export hardware topology to {} ({})",
                base_path, strerror(err)
            );
            return QV_ERR;
        }

        int topo_xml_len = 0;
        rc = hwloc_topology_export_xmlbuffer(
            m_topo, &topo_xml, &topo_xml_len,
            0 // We don't need 1.x compatible XML export.
        );
        if (qvi_unlikely(rc == -1)) {
            ers = "hwloc_topology_export_xmlbuffer() failed";
            qvrc = QV_ERR_HWLOC;
            break;
        }

        m_topo_file = topo_fname(base_path, flags());

        qvrc = s_topo_fopen(m_topo_file, &fd);
        if (qvi_unlikely(qvrc != QV_SUCCESS)) {
            ers = "topo_fopen() failed";
            break;
        }

        rc = write(fd, topo_xml, topo_xml_len);
        if (qvi_unlikely(rc == -1 || rc != topo_xml_len)) {
            const int err = errno;
            ers = "write() failed";
            qvi_log_error("{} {}", ers, strerror(err));
            qvrc = QV_ERR_FILE_IO;
            break;
        }
    } while (false);

    if (qvi_unlikely(ers)) {
        qvi_log_error("{} with rc={} ({})", ers, qvrc, qv_strerr(qvrc));
    }
    hwloc_free_xmlbuffer(m_topo, topo_xml);
    (void)close(fd);
    return qvrc;
}

hwloc_topology_t
qvi_hwloc::topology_get(void)
{
    return m_topo;
}

std::string
qvi_hwloc::topology_file(void)
{
    return m_topo_file;
}

bool
qvi_hwloc::topology_is_this_system(void)
{
    return !!hwloc_topology_is_thissystem(topology_get());
}

qvi_hwloc_bitmap
qvi_hwloc::topology_get_cpuset(void)
{
    qvi_hwloc_bitmap result;
    const int rc = hwloc_bitmap_and(
        result.data(),
        hwloc_topology_get_allowed_cpuset(m_topo),
        hwloc_topology_get_topology_cpuset(m_topo)
    );
    if (qvi_unlikely(rc != 0)) throw qvi_runtime_error(QV_ERR_HWLOC);
    return result;
}

qvi_hwloc_bitmap
qvi_hwloc::topology_get_system_cpuset(void)
{
    return qvi_hwloc_bitmap(hwloc_topology_get_topology_cpuset(m_topo));
}

int
qvi_hwloc::obj_type_depth(
    qv_hw_type_t type,
    int *depth
) const {
    *depth = hwloc_get_type_depth(
        m_topo, qvi_hwloc::obj_get_type(type)
    );
    return QV_SUCCESS;
}

int
qvi_hwloc::m_get_logical_bind_string(
    hwloc_const_bitmap_t bitmap,
    std::string &result
) const {
    result.clear();

    const int num_pus = hwloc_get_nbobjs_inside_cpuset_by_type(
        m_topo, bitmap, HWLOC_OBJ_PU
    );

    hwloc_obj_t obj_pu = nullptr;
    qvi_hwloc_bitmap logical_bitmap;
    for (int i = 0; i < num_pus; ++i) {
        obj_pu = hwloc_get_next_obj_inside_cpuset_by_type(
            m_topo, bitmap, HWLOC_OBJ_PU, obj_pu
        );
        (void)hwloc_bitmap_set(logical_bitmap.data(), obj_pu->logical_index);
    }

    result.append("L");
    result.append(qvi_hwloc::bitmap_list_string(logical_bitmap.cdata()));

    return QV_SUCCESS;
}

int
qvi_hwloc::m_get_physical_bind_string(
    hwloc_const_bitmap_t bitmap,
    std::string &result
) const {
    result.clear();

    result.append("P");
    result.append(qvi_hwloc::bitmap_list_string(bitmap));

    return QV_SUCCESS;
}

int
qvi_hwloc::bind_string(
    hwloc_const_bitmap_t bitmap,
    qv_bind_string_flags_t flags,
    char **result
) {
    *result = nullptr;

    int rc = QV_SUCCESS;
    const std::string sep = " ; ";
    std::string lresult;
    std::string presult;
    std::string iresult;

    if (flags & QV_BIND_STRING_LOGICAL) {
        rc = m_get_logical_bind_string(bitmap, lresult);
        if (qvi_unlikely(rc != QV_SUCCESS)) return rc;

        iresult.append(lresult);
    }
    if (flags & QV_BIND_STRING_PHYSICAL) {
        rc = m_get_physical_bind_string(bitmap, presult);
        if (qvi_unlikely(rc != QV_SUCCESS)) return rc;

        if (!iresult.empty()) {
            iresult.append(sep);
        }
        iresult.append(presult);
    }
    // Sanity check. This means that no valid flag paths were taken. This
    // likely means that an invalid flag was provided to the function.
    if (qvi_unlikely(iresult.empty())) {
        return QV_ERR_INVLD_ARG;
    }
    //
    const int np = asprintf(result, "%s", iresult.c_str());
    if (qvi_unlikely(np == -1)) {
        *result = nullptr;
        return QV_ERR_OOR;
    }
    return QV_SUCCESS;
}

int
qvi_hwloc::m_set_device_info(
    hwloc_obj_t obj,
    const std::string &pci_bus_id,
    qvi_hwloc_device *device
) {
    std::string uuid_info_name = {};
    switch (obj->attr->osdev.type) {
        case HWLOC_OBJ_OSDEV_GPU: {
            device->type = QV_HW_GPU;
            const auto vendor_info = get_obj_info_by_name(obj, "GPUVendor");
            // Expecting something like AMD or NVIDIA Corporation.
            const auto vendor = qvi_split_string(vendor_info, " ").at(0);
            uuid_info_name = vendor + "UUID";
            break;
        }
        case HWLOC_OBJ_OSDEV_COPROC: {
            device->type = QV_HW_GPU;
            if (obj_has_subtype(obj, "LevelZero")) {
                uuid_info_name = "LevelZeroUUID";
            }
            break;
        }
        case HWLOC_OBJ_OSDEV_OPENFABRICS: {
            device->type = QV_HW_NIC;
            uuid_info_name = "NodeGUID";
            break;
        }
        case HWLOC_OBJ_OSDEV_NETWORK: {
            device->type = QV_HW_NIC;
            if (obj_has_subtype(obj, "BXI")) uuid_info_name = "BXIUUID";
            else uuid_info_name = "Address";
            break;
        }
        default:
            return QV_SUCCESS;
    }
    // Save the device name.
    device->name = std::string(obj->name);
    // Set the device ID.
    device->id = get_dev_id_from_name(obj->name);
    // Set the PCI bus ID.
    device->pci_bus_id = pci_bus_id;
    // Set the UUID.
    device->uuid = get_obj_info_by_name(obj, uuid_info_name);
    // Set the affinity.
    return m_set_device_affinity_by_pci_bus_id(
        pci_bus_id, device
    );
}

/**
 * Why use this method to get device affinity? I've noticed that in other
 * dynamic environments calls to things like nvmlInit() and rsmi_init() might
 * setup GPU infrastructure that persists for the life of the process based on
 * the state of the system at initialization. In static environments this is
 * likely fine. In dynamic environments, however, this might be problematic
 * since the ultimate setup may differ (e.g., fewer processes using the GPUs).
 * Basically we are avoiding somewhat speculative setups by discovering device
 * affinities in this way. A bonus is that synthetic topologies work with this
 * approach.
 *
 * We prefer the tightest accurate affinity bound for the device. Starting from
 * the device's closest non-I/O ancestor (the CPU/memory node the PCI bus is
 * physically wired to), we consider two candidate cpusets:
 *   1. The NUMA-local cpuset, derived from the ancestor's nodeset. On
 *      sub-NUMA-clustering machines (multiple NUMA nodes per package) this is
 *      tighter than the package and more accurately reflects memory locality.
 *   2. The enclosing Package (CPU socket) cpuset, found by walking up parents.
 * We select whichever is narrower (fewer PUs), which never broadens affinity
 * relative to using the package alone and tightens it when NUMA locality is
 * more specific. If neither is resolvable (e.g. a non-NUMA architecture with no
 * package), we fall back to the allowed topology resources.
 */
int
qvi_hwloc::m_set_device_affinity_by_pci_bus_id(
    const std::string &busid,
    qvi_hwloc_device *dev
) {
    int rc = QV_SUCCESS;
    do {
        hwloc_obj_t pci_dev = hwloc_get_pcidev_by_busidstring(
            m_topo, busid.c_str()
        );
        if (qvi_unlikely(!pci_dev)) {
            rc = QV_ERR_NOT_FOUND;
            break;
        }
        // Jump to the closest non-I/O ancestor. This is the
        // CPU/Memory node the PCI bus is physically wired to.
        hwloc_obj_t ancestor = hwloc_get_non_io_ancestor_obj(m_topo, pci_dev);
        if (qvi_unlikely(!ancestor)) {
            rc = QV_ERR_NOT_FOUND;
            break;
        }
        // The NUMA-local cpuset. NUMA nodes are memory objects and
        // are not part of the normal parent chain, so we derive their locality
        // from the ancestor's nodeset rather than by walking parents. This is
        // only meaningful when the topology actually exposes NUMA structure.
        qvi_hwloc_bitmap numa_cpuset;
        bool have_numa = false;
        if (hwloc_get_nbobjs_by_depth(m_topo, HWLOC_TYPE_DEPTH_NUMANODE) > 0 &&
            ancestor->nodeset != nullptr &&
            !hwloc_bitmap_iszero(ancestor->nodeset)) {
            const int frc = hwloc_cpuset_from_nodeset(
                m_topo, numa_cpuset.data(), ancestor->nodeset
            );
            if (qvi_likely(frc == 0) &&
                !hwloc_bitmap_iszero(numa_cpuset.cdata())) {
                have_numa = true;
            }
        }
        // The enclosing package (i.e., CPU socket) cpuset.
        hwloc_obj_t package = ancestor;
        while (package && package->type != HWLOC_OBJ_PACKAGE) {
            package = package->parent;
        }
        const bool have_package = (package != nullptr);
        // Select the tightest (narrowest) available candidate.
        if (have_numa && have_package) {
            const int numa_w = hwloc_bitmap_weight(numa_cpuset.cdata());
            const int pack_w = hwloc_bitmap_weight(package->cpuset);
            // Prefer NUMA on ties: it reflects memory locality most directly.
            if (numa_w <= pack_w) {
                dev->affinity.set(numa_cpuset.cdata());
            }
            else {
                dev->affinity.set(package->cpuset);
            }
        }
        else if (have_numa) {
            dev->affinity.set(numa_cpuset.cdata());
        }
        else if (have_package) {
            dev->affinity.set(package->cpuset);
        }
        else {
            rc = QV_ERR_NOT_FOUND;
            break;
        }
    } while (false);
    if (qvi_unlikely(rc != QV_SUCCESS)) {
        // Do our best here: just set it to the allowed resources.
        return dev->affinity.set(topology_get_cpuset().cdata());
    }
    return QV_SUCCESS;
}

int
qvi_hwloc::m_discover_devices(void)
{
    // This will maintain a mapping of PCI bus IDs to devices.
    std::map<std::string, std::shared_ptr<qvi_hwloc_device>> devmap;

    hwloc_obj_t obj = nullptr;
    while ((obj = hwloc_get_next_osdev(m_topo, obj)) != nullptr) {
        // Skip this object?
        if (!keep_os_device(obj)) continue;
        // Try to get the PCI object.
        const auto [pci_obj, busid] = get_pci_info(obj);
        if (!pci_obj) continue;
        std::shared_ptr<qvi_hwloc_device> dev = nullptr;
        // Have we seen this device already? For example, opencl0d0
        // and cuda0 may correspond to the same GPU hardware.
        auto got = devmap.find(busid);
        // New device (i.e., a new PCI bus ID).
        if (got == devmap.end()) {
            dev = std::make_shared<qvi_hwloc_device>();
            // Add it to our collection of 'seen' devices.
            devmap.insert({busid, dev});
        }
        else {
            dev = got->second;
        }
        // Set the information on the device. This could be the first time that
        // the device has been seen, or the nth time.
        const int rc = m_set_device_info(obj, busid, dev.get());
        if (qvi_unlikely(rc != QV_SUCCESS)) return rc;
    }
    // Now that we have all the device information that we are going to get,
    // populate the final device map.
    for (const auto &[pci_busid, dev] : devmap) {
        // Add the new device to our map of available devices.
        auto [it, inserted] = m_devmap.try_emplace(dev.get()->type);
        it->second.emplace_back(std::move(dev));
    }
    // Sort devices based on ID.
    for (auto &[dev_type, devlist] : m_devmap) {
        std::sort(
            devlist.begin(),
            devlist.end(),
            [](const std::shared_ptr<qvi_hwloc_device> &a,
               const std::shared_ptr<qvi_hwloc_device> &b) {
                return a.get()->id < b.get()->id; // Sort ascending.
            }
        );
    }
    return QV_SUCCESS;
}

int
qvi_hwloc::get_nobjs_by_type(
   qv_hw_type_t target_type,
   int *out_nobjs
) {
    int depth = HWLOC_TYPE_DEPTH_UNKNOWN;
    const int rc = obj_type_depth(target_type, &depth);
    if (qvi_unlikely(rc != QV_SUCCESS)) return rc;

    *out_nobjs = hwloc_get_nbobjs_by_depth(m_topo, depth);
    return rc;
}

int
qvi_hwloc::task_get_cpubind(
    pid_t who,
    qvi_hwloc_bitmap &result
) {
    const int rc = hwloc_get_proc_cpubind(
        m_topo, who, result.data(), HWLOC_CPUBIND_THREAD
    );
    if (qvi_unlikely(rc != 0)) return QV_ERR_HWLOC;
    // A task's binding may map onto topology resources that are disallowed by
    // mechanisms such as cgroups. Constrain the result to the allowed
    // (cgroup-obeying) cpuset so that per-task scopes never exceed the
    // user-visible resources.
    const int arc = hwloc_bitmap_and(
        result.data(),
        result.cdata(),
        topology_get_cpuset().cdata()
    );
    if (qvi_unlikely(arc != 0)) {
        return QV_ERR_HWLOC;
    }
    return QV_SUCCESS;
}

int
qvi_hwloc::task_set_cpubind_from_cpuset(
    pid_t task_id,
    hwloc_const_cpuset_t cpuset
) {
    const int rc = hwloc_set_proc_cpubind(
        m_topo, task_id, cpuset, HWLOC_CPUBIND_THREAD
    );
    if (qvi_unlikely(rc != 0)) return QV_ERR_NOT_SUPPORTED;
    return QV_SUCCESS;
}

int
qvi_hwloc::m_obj_get_by_type(
    qv_hw_type_t type,
    int type_index,
    hwloc_obj_t *obj
) {
    const hwloc_obj_type_t obj_type = qvi_hwloc::obj_get_type(type);
    *obj = hwloc_get_obj_by_type(
        m_topo, obj_type, static_cast<uint_t>(type_index)
    );
    return (*obj != nullptr ? QV_SUCCESS : QV_ERR_HWLOC);
}

/**
 *
 */
int
qvi_hwloc::m_task_obj_xop_by_type_id(
    qv_hw_type_t type,
    pid_t task_id,
    int type_index,
    task_xop_obj_id opid,
    int *result
) {
    hwloc_obj_t obj;
    int rc = m_obj_get_by_type(type, type_index, &obj);
    if (qvi_unlikely(rc != QV_SUCCESS)) return rc;

    qvi_hwloc_bitmap cur_bind;
    rc = task_get_cpubind(task_id, cur_bind);
    if (qvi_unlikely(rc != QV_SUCCESS)) return rc;

    switch (opid) {
        case TASK_INTERSECTS_OBJ:
            *result = hwloc_bitmap_intersects(cur_bind.cdata(), obj->cpuset);
            break;
        case TASK_INCLUDEDIN_OBJ:
            *result = hwloc_bitmap_isincluded(cur_bind.cdata(), obj->cpuset);
            break;
        [[unlikely]] default:
            // Something bad happened to get here.
            qvi_abort();
    }
    return QV_SUCCESS;
}

int
qvi_hwloc::task_intersects_obj_by_type_id(
    qv_hw_type_t type,
    pid_t task_id,
    int type_index,
    int *result
) {
    return m_task_obj_xop_by_type_id(
        type, task_id, type_index, TASK_INTERSECTS_OBJ, result
    );
}

int
qvi_hwloc::task_includedin_obj_by_type_id(
    qv_hw_type_t type,
    pid_t task_id,
    int type_index,
    int *result
) {
    return m_task_obj_xop_by_type_id(
        type, task_id, type_index, TASK_INCLUDEDIN_OBJ, result
    );
}

int
qvi_hwloc::m_get_nosdevs_in_cpuset(
    const qvi_hwloc_dev_list &devs,
    hwloc_const_cpuset_t cpuset,
    size_t &nobjs
) const {
    nobjs = 0;
    for (const auto &dev : devs) {
        if (hwloc_bitmap_isincluded(dev->affinity.cdata(), cpuset)) nobjs++;
    }
    return QV_SUCCESS;
}

int
qvi_hwloc::m_get_nobjs_in_cpuset(
    qv_hw_type_t target_obj,
    hwloc_const_cpuset_t cpuset,
    size_t &nobjs
) const {
    int depth;
    int rc = obj_type_depth(target_obj, &depth);
    if (qvi_unlikely(rc != QV_SUCCESS)) return rc;

    nobjs = 0;
    hwloc_obj_t obj = nullptr;
    while ((obj = hwloc_get_next_obj_by_depth(m_topo, depth, obj))) {
        if (!hwloc_bitmap_isincluded(obj->cpuset, cpuset)) continue;
        // Ignore objects with empty sets (can happen when outside of cgroup).
        if (hwloc_bitmap_iszero(obj->cpuset)) continue;
        nobjs++;
    }
    return QV_SUCCESS;
}

int
qvi_hwloc::get_nobjs_in_cpuset(
    qv_hw_type_t target_obj,
    hwloc_const_cpuset_t cpuset,
    size_t &nobjs
) const {
    switch (target_obj) {
        case(QV_HW_GPU) :
        case(QV_HW_NIC) :
            return m_get_nosdevs_in_cpuset(
                cget_dev_list(m_devmap, target_obj), cpuset, nobjs
            );
        default:
            return m_get_nobjs_in_cpuset(target_obj, cpuset, nobjs);
    }
}

int
qvi_hwloc::get_obj_in_cpuset_by_depth(
    hwloc_const_cpuset_t cpuset,
    int depth,
    int index,
    hwloc_obj_t *result_obj
) const {
    *result_obj = hwloc_get_obj_inside_cpuset_by_depth(
        m_topo, cpuset, depth, index
    );

    return (*result_obj != nullptr ? QV_SUCCESS : QV_ERR_HWLOC);
}

const std::vector<qv_hw_type_t> &
qvi_hwloc::supported_devices(void) {
    static const std::vector<qv_hw_type_t> supported_devices = {
        QV_HW_GPU,
        QV_HW_NIC
    };
    return supported_devices;
}

int
qvi_hwloc::devices_emit(
    qv_hw_type_t obj_type
) const {
    for (auto &dev : cget_dev_list(m_devmap, obj_type)) {
        const std::string cpusets = qvi_hwloc::bitmap_list_string(
            dev->affinity.cdata()
        );
        qvi_log_info("  Device Name: {}", dev->name);
        qvi_log_info("  Device PCI Bus ID: {}", dev->pci_bus_id);
        qvi_log_info("  Device UUID: {}", dev->uuid);
        qvi_log_info("  Device affinity: {}", cpusets);
        qvi_log_info("  Device Visible Device ID: {}\n", dev->id);
    }
    return QV_SUCCESS;
}

static int
get_devices_in_cpuset_from_dev_list(
    const qvi_hwloc_dev_list &devlist,
    hwloc_const_cpuset_t cpuset,
    qvi_hwloc_dev_list &devs
) {
    devs.clear();
    for (const auto &dev : devlist) {
        if (!hwloc_bitmap_isincluded(dev->affinity.cdata(), cpuset)) continue;
        // Else add the included device.
        devs.emplace_back(dev);
    }
    return QV_SUCCESS;
}

int
qvi_hwloc::get_devices_included_in_cpuset(
    qv_hw_type_t obj_type,
    hwloc_const_cpuset_t cpuset,
    qvi_hwloc_dev_list &devs
) const {
    return get_devices_in_cpuset_from_dev_list(
        cget_dev_list(m_devmap, obj_type), cpuset, devs
    );
}

int
qvi_hwloc::get_device_id_in_cpuset(
    qv_hw_type_t dev_obj,
    int i,
    hwloc_const_cpuset_t cpuset,
    qv_dev_id_type_t dev_id_type,
    std::string &dev_id
) {
    qvi_hwloc_dev_list devs;
    int rc = get_devices_included_in_cpuset(dev_obj, cpuset, devs);
    if (qvi_unlikely(rc != QV_SUCCESS)) return rc;

    switch (dev_id_type) {
        case (QV_DEV_ID_UUID):
            dev_id = devs.at(i)->uuid;
            break;
        case (QV_DEV_ID_PCI_BUS_ID):
            dev_id = devs.at(i)->pci_bus_id;
            break;
        case (QV_DEV_ID_ORDINAL):
            dev_id = std::to_string(devs.at(i)->id);
            break;
        [[unlikely]] default:
            rc = QV_ERR_INVLD_ARG;
            break;
    }
    return rc;
}

int
qvi_hwloc::get_cpuset_for_nobjs(
    const qvi_hwloc_bitmap &cpuset,
    qv_hw_type_t obj_type,
    uint_t nobjs,
    qvi_hwloc_bitmap &result
) {
    // Zero-out the result bitmap that will encode the result.
    hwloc_bitmap_zero(result.data());
    // Get the target object's depth.
    int obj_depth;
    int rc = obj_type_depth(obj_type, &obj_depth);
    if (qvi_unlikely(rc != QV_SUCCESS)) return rc;
    // Calculate cpuset based on number of desired objects.
    for (uint_t i = 0; i < nobjs; ++i) {
        hwloc_obj_t dobj;
        rc = get_obj_in_cpuset_by_depth(
            cpuset.cdata(), obj_depth, i, &dobj
        );
        if (qvi_unlikely(rc != QV_SUCCESS)) break;

        const int orrc = hwloc_bitmap_or(
            result.data(), result.cdata(), dobj->cpuset
        );
        if (qvi_unlikely(orrc != 0)) {
            rc = QV_ERR_HWLOC;
            break;
        }
    }
    return rc;
}

int
qvi_hwloc::m_disable_smt(void)
{
    // Get the entire topology.
    qvi_hwloc_bitmap orig_bitmap = topology_get_system_cpuset();
    // How many cores are in the unmodified bitmap?
    const uint_t ncores = hwloc_get_nbobjs_inside_cpuset_by_type(
        m_topo, orig_bitmap.cdata(), HWLOC_OBJ_CORE
    );

    qvi_hwloc_bitmap nosmt_bitmap;
    for (uint_t i = 0; i < ncores; ++i) {
        hwloc_obj_t obj = hwloc_get_obj_inside_cpuset_by_type(
            m_topo, orig_bitmap.cdata(), HWLOC_OBJ_CORE, i
        );
        qvi_hwloc_bitmap core_cpuset(obj->cpuset);
        hwloc_bitmap_singlify(core_cpuset.data());
        hwloc_bitmap_or(
            nosmt_bitmap.data(), nosmt_bitmap.cdata(), core_cpuset.cdata()
        );
    }
    // Now modify the underlying topology's cpuset to remove the hyper-threads.
    const int rc = hwloc_topology_restrict(m_topo, nosmt_bitmap.cdata(), 0);
    if (qvi_unlikely(rc != 0)) {
        return QV_ERR_HWLOC;
    }
    return QV_SUCCESS;
}

/*
 * vim: ft=cpp ts=4 sts=4 sw=4 expandtab
 */
