/* -*- Mode: C++; c-basic-offset:4; indent-tabs-mode:nil -*- */
/*
 * Copyright (c) 2022-2026 Triad National Security, LLC
 *                         All rights reserved.
 *
 * This file is part of the quo-vadis project. See the LICENSE file at the
 * top-level directory of this distribution.
 */

/**
 * @file qvi-hwpool.cc
 *
 * Hardware Resource Pool
 */

#include "qvi-hwpool.h"

qv_scope_flags_t
qvi_hwpool_res::flags(void) const
{
    return m_flags;
}

const qvi_hwloc_bitmap &
qvi_hwpool_res::affinity(void) const
{
    return m_affinity;
}

qvi_hwpool_dev::qvi_hwpool_dev(
    const qvi_hwloc_device &dev
) : qvi_hwpool_res(dev.affinity)
  , m_type(dev.type)
  , m_id(dev.id)
  , m_pci_bus_id(dev.pci_bus_id)
  , m_uuid(dev.uuid) { }

qvi_hwpool_dev::qvi_hwpool_dev(
    const std::shared_ptr<qvi_hwloc_device> &shdev
) : qvi_hwpool_dev(*shdev.get()) { }

std::string
qvi_hwpool_dev::id(
    qv_dev_id_type_t format
) const {
    switch (format) {
        case (QV_DEV_ID_UUID):
            return m_uuid;
        case (QV_DEV_ID_PCI_BUS_ID):
            return m_pci_bus_id;
        case (QV_DEV_ID_ORDINAL):
            return std::to_string(m_id);
        [[unlikely]] default:
            throw qvi_runtime_error(QV_ERR_INVLD_ARG);
    }
}

int
qvi_hwpool_dev::id(
    qv_dev_id_type_t format,
    char **result
) const {
    int rc = QV_SUCCESS;

    const std::string ids = id(format);
    const int nw = asprintf(result, "%s", ids.c_str());
    if (qvi_unlikely(nw == -1)) rc = QV_ERR_OOR;

    if (qvi_unlikely(rc != QV_SUCCESS)) {
        *result = nullptr;
    }
    return rc;
}

bool
qvi_hwpool::m_device_in_pool(
    const qvi_hwpool_dev &dev
) const {
    for (const auto &pool_dev : devices(dev.type())) {
        if (*pool_dev.get() == dev) return true;
    }
    return false;
}

int
qvi_hwpool::m_add_devices_with_affinity(
    const qvi_hwloc &hwloc
) {
    // Iterate over the supported device types.
    for (const auto devt : qvi_hwloc::supported_devices()) {
        qvi_hwloc_dev_list devs;
        const int rc = hwloc.get_devices_included_in_cpuset(
            devt, m_cpu.affinity().cdata(), devs
        );
        if (qvi_unlikely(rc != QV_SUCCESS)) return rc;
        for (const auto &dev : devs) {
            add_device(qvi_hwpool_dev(dev));
        }
    }
    return QV_SUCCESS;
}

int
qvi_hwpool::populate(
    const qvi_hwloc &hwloc,
    const qvi_hwloc_bitmap &cpuset
) {
    m_cpu = qvi_hwpool_cpu(cpuset);
    // Add devices with affinity to the hardware pool.
    return m_add_devices_with_affinity(hwloc);
}

const qvi_hwloc_bitmap &
qvi_hwpool::cpuset(void) const
{
    return m_cpu.affinity();
}

const qvi_hwpool::dev_list_t &
qvi_hwpool::devices(
    qv_hw_type_t obj_type
) const {
    static const dev_list_t empty_list = {};
    if (!m_dev_map.contains(obj_type)) return empty_list;
    return m_dev_map.at(obj_type);
}

std::vector<qvi_hwloc_bitmap>
qvi_hwpool::device_affinities(
    qv_hw_type_t obj_type
) const {
    switch (qvi_hwloc::obj_res_class(obj_type)) {
        case QVI_HWLOC_RES_CLASS_DEV: {
            std::vector<qvi_hwloc_bitmap> result;
            for (const auto &dev : devices(obj_type)) {
                result.emplace_back(dev.get()->affinity());
            }
            return result;
        }
        [[unlikely]] default:
            throw qvi_runtime_error(QV_ERR_NOT_SUPPORTED);
    }
}

size_t
qvi_hwpool::nobjects(
    const qvi_hwloc &hwloc,
    qv_hw_type_t obj_type
) const {
    switch (qvi_hwloc::obj_res_class(obj_type)) {
        case QVI_HWLOC_RES_CLASS_HOST: {
            size_t result;
            const int rc = hwloc.get_nobjs_in_cpuset(
                obj_type, m_cpu.affinity().cdata(), result
            );
            if (qvi_unlikely(rc != QV_SUCCESS)) throw qvi_runtime_error(rc);
            return result;
        }
        default:
        // Note that this path also covers QVI_HWLOC_RES_LAST because result
        // will be 0 in the case that obj_type is QV_HW_LAST.
        return devices(obj_type).size();
    }
}

void
qvi_hwpool::add_device(
    const qvi_hwpool_dev &dev
) {
    if (!m_device_in_pool(dev)) {
        // Safely ensure the vector exists, get iterator to it.
        auto [it, _] = m_dev_map.try_emplace(dev.type());
        // Push the new item safely into the vector.
        it->second.emplace_back(std::make_shared<qvi_hwpool_dev>(dev));
        // Sort the list by device ID after each
        // insertion to maintain correct device ordinals.
        std::sort(
            it->second.begin(),
            it->second.end(),
            [](const std::shared_ptr<qvi_hwpool_dev> &a,
               const std::shared_ptr<qvi_hwpool_dev> &b) {
                return a.get()->id() < b.get()->id(); // Sort ascending.
            }
        );
    }
}

std::vector<qvi_hwloc_bitmap>
qvi_hwpool::cpusets(
    const std::vector<qvi_hwpool> &hwpools
) {
    std::vector<qvi_hwloc_bitmap> result;
    for (const auto &hwpool : hwpools) {
        result.emplace_back(hwpool.cpuset());
    }
    return result;
}

qvi_hwpool
qvi_hwpool::set_union(
    const std::vector<qvi_hwpool> &hwpools
) {
    // Calculate the union of the hardware pool cpusets.
    qvi_hwloc_bitmap cpu_union;
    for (const auto &hwpool : hwpools) {
        cpu_union = cpu_union | hwpool.cpuset();
    }
    // Create the result hardware pool with the proper cpuset.
    qvi_hwpool result(cpu_union);
    // Do the same for its devices. Note that add_device() shall protect against
    // multiple insertions of the same device into the hardware pool.
    for (const auto &hwpool : hwpools) {
        for (const auto devt : qvi_hwloc::supported_devices()) {
            for (const auto &dev : hwpool.devices(devt)) {
                result.add_device(*dev.get());
            }
        }
    }
    return result;
}

/*
 * vim: ft=cpp ts=4 sts=4 sw=4 expandtab
 */
