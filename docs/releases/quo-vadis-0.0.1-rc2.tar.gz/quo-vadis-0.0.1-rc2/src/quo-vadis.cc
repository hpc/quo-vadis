/* -*- Mode: C++; c-basic-offset:4; indent-tabs-mode:nil -*- */
/*
 * Copyright (c) 2020-2026 Triad National Security, LLC
 *                         All rights reserved.
 *
 * Copyright (c) 2020-2021 Lawrence Livermore National Security, LLC
 *                         All rights reserved.
 *
 * This file is part of the quo-vadis project. See the LICENSE file at the
 * top-level directory of this distribution.
 */

/**
 * @file quo-vadis.cc
 */

#include "qvi-group-process.h"
#include "qvi-scope.h"

int
qv_version(
    int *major,
    int *minor,
    int *patch
) {
    if (qvi_unlikely(!major || !minor || !patch)) {
        return QV_ERR_INVLD_ARG;
    }

    *major = PACKAGE_VERSION_MAJOR;
    *minor = PACKAGE_VERSION_MINOR;
    *patch = PACKAGE_VERSION_PATCH;

    return QV_SUCCESS;
}

static inline int
qvi_process_scope_get(
    qv_scope_intrinsic_t iscope,
    qv_scope_flags_t flags,
    qv_scope_t **scope
) {
    // Create the base process group.
    qvi_group_process *zgroup = new qvi_group_process(flags);
    return qv_scope::make_intrinsic(zgroup, iscope, flags, scope);
}

int
qv_process_scope(
    qv_scope_intrinsic_t iscope,
    qv_scope_flags_t flags,
    qv_scope_t **scope
) {
    if (qvi_unlikely(!scope)) {
        return QV_ERR_INVLD_ARG;
    }
    try {
        return qvi_process_scope_get(iscope, flags, scope);
    }
    qvi_catch_and_return();
}

int
qv_bind_push(
    qv_scope_t *scope
) {
    if (qvi_unlikely(!scope)) {
        return QV_ERR_INVLD_ARG;
    }
    try {
        return scope->bind_push();
    }
    qvi_catch_and_return();
}

int
qv_bind_pop(
    qv_scope_t *scope
) {
    if (qvi_unlikely(!scope)) {
        return QV_ERR_INVLD_ARG;
    }
    try {
        return scope->bind_pop();
    }
    qvi_catch_and_return();
}

int
qv_bind_string(
    qv_scope_t *scope,
    qv_bind_string_flags_t flags,
    char **str
) {
    if (qvi_unlikely(!scope || !str)) {
        return QV_ERR_INVLD_ARG;
    }
    try {
        return scope->bind_string(flags, str);
    }
    qvi_catch_and_return();
}

int
qv_free(
    qv_scope_t *scope
) {
    // Just accept NULL like free() does.
    if (!scope) {
        return QV_SUCCESS;
    }
    try {
        qvi_delete(&scope);
        return QV_SUCCESS;
    }
    qvi_catch_and_return();
}

int
qv_hw_count(
    qv_scope_t *scope,
    qv_hw_type_t obj,
    int *nobjs
) {
    if (qvi_unlikely(!scope || !nobjs)) {
        return QV_ERR_INVLD_ARG;
    }
    try {
        *nobjs = static_cast<int>(scope->hwpool_nobjects(obj));
        return QV_SUCCESS;
    }
    qvi_catch_and_return();
}

int
qv_group_rank(
    qv_scope_t *scope,
    int *rank
) {
    if (qvi_unlikely(!scope || !rank)) {
        return QV_ERR_INVLD_ARG;
    }
    try {
        *rank = scope->group_rank();
        return QV_SUCCESS;
    }
    qvi_catch_and_return();
}

int
qv_group_size(
    qv_scope_t *scope,
    int *group_size
) {
    if (qvi_unlikely(!scope || !group_size)) {
        return QV_ERR_INVLD_ARG;
    }
    try {
        *group_size = scope->group_size();
        return QV_SUCCESS;
    }
    qvi_catch_and_return();
}

int
qv_barrier(
    qv_scope_t *scope
) {
    if (qvi_unlikely(!scope)) {
        return QV_ERR_INVLD_ARG;
    }
    try {
        return scope->group_barrier();
    }
    qvi_catch_and_return();
}

int
qv_create_scope(
    qv_scope_t *scope,
    qv_scope_flags_t flags,
    qv_hw_type_t type,
    int nobjs,
    qv_scope_t **subscope
) {
    if (qvi_unlikely(!scope || (nobjs < 0) || !subscope)) {
        return QV_ERR_INVLD_ARG;
    }
    // Initialize the output so callers always observe a well-defined value,
    // even if an exception is thrown below.
    *subscope = nullptr;
    try {
        return scope->create(flags, type, nobjs, subscope);
    }
    qvi_catch_and_return();
}

int
qv_split(
    qv_scope_t *scope,
    int npieces,
    int group_id,
    qv_scope_t **subscope
) {
    if (qvi_unlikely(!scope || (npieces <= 0) || !subscope)) {
        return QV_ERR_INVLD_ARG;
    }
    // Initialize the output so callers always observe a well-defined value,
    // even if an exception is thrown below.
    *subscope = nullptr;
    try {
        // We use the sentinel value QV_HW_LAST to differentiate between
        // calls from split() and split_at(). Since this call doesn't have a
        // hardware type argument, we use QV_HW_LAST as the hardware type.
        return scope->split(npieces, group_id, QV_HW_LAST, subscope);
    }
    qvi_catch_and_return();
}

int
qv_split_at(
    qv_scope_t *scope,
    qv_hw_type_t type,
    int group_id,
    qv_scope_t **subscope
) {
    if (qvi_unlikely(!scope || !subscope)) {
        return QV_ERR_INVLD_ARG;
    }
    // Initialize the output so callers always observe a well-defined value,
    // even if an exception is thrown below.
    *subscope = nullptr;
    try {
        return scope->split_at(type, group_id, subscope);
    }
    qvi_catch_and_return();
}

int
qv_dev_id(
    qv_scope_t *scope,
    qv_hw_type_t dev_obj,
    int dev_index,
    qv_dev_id_type_t id_type,
    char **dev_id
) {
    if (qvi_unlikely(!scope || (dev_index < 0) || !dev_id)) {
        return QV_ERR_INVLD_ARG;
    }
    try {
        return scope->device_id(dev_obj, dev_index, id_type, dev_id);
    }
    qvi_catch_and_return();
}

/*
 * vim: ft=cpp ts=4 sts=4 sw=4 expandtab
 */
