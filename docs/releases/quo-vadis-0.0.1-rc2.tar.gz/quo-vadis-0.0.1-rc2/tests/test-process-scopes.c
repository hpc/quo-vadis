/* -*- Mode: C; c-basic-offset:4; indent-tabs-mode:nil -*- */

#include "quo-vadis.h"
#include "common-test-utils.h"

int
main(void)
{
    qv_scope_t *self_scope = NULL;
    ctu_check(
        qv_process_scope(QV_SCOPE_PROCESS, QV_SCOPE_FLAG_NONE, &self_scope)
    );

    ctu_emit_scope_report(
        self_scope, CTU_SCOPE_KIND_PROCESS, "     self_scope"
    );

    ctu_check(qv_free(self_scope));

    qv_scope_t *base_scope;
    ctu_check(qv_process_scope(QV_SCOPE_USER, QV_SCOPE_FLAG_NONE, &base_scope));

    ctu_emit_scope_report(
        base_scope, CTU_SCOPE_KIND_PROCESS, "     base_scope"
    );

    int sgsize;
    ctu_check(qv_group_size(base_scope, &sgsize));
    if (sgsize != 1) {
        ctu_panic("Invalid number of tasks detected (size=%d)", sgsize);
    }

    ctu_emit_host_hw_info(
        base_scope, CTU_SCOPE_KIND_PROCESS, "     base_scope"
    );
    ctu_emit(base_scope, CTU_SCOPE_KIND_PROCESS, "\n");

    const int npieces = 2;
    // Provided color in range, so we will get the LHS of the split.
    // That is, with 2 pieces, the in-range coloring values are 0 and 1.
    qv_scope_t *sub_scope_left;
    ctu_check(qv_split(base_scope, npieces, 0, &sub_scope_left));
    // Provided color in range, so we will get the RHS of the split.
    // That is, with 2 pieces, the in-range coloring values are 0 and 1.
    qv_scope_t *sub_scope_right;
    ctu_check(qv_split(base_scope, npieces, 1, &sub_scope_right));

    ctu_emit_host_hw_info(
        sub_scope_left, CTU_SCOPE_KIND_PROCESS, " sub_scope_left"
    );
    ctu_emit_scope_report(
        sub_scope_left, CTU_SCOPE_KIND_PROCESS, " sub_scope_left"
    );
    ctu_emit(sub_scope_left, CTU_SCOPE_KIND_PROCESS, "\n");
    ctu_emit_host_hw_info(
        sub_scope_right, CTU_SCOPE_KIND_PROCESS, "sub_scope_right"
    );
    ctu_emit_scope_report(
        sub_scope_right, CTU_SCOPE_KIND_PROCESS, "sub_scope_right"
    );

    ctu_check(qv_free(base_scope));

    ctu_check(qv_free(sub_scope_left));

    ctu_check(qv_free(sub_scope_right));

    return EXIT_SUCCESS;
}

/*
 * vim: ft=cpp ts=4 sts=4 sw=4 expandtab
 */
