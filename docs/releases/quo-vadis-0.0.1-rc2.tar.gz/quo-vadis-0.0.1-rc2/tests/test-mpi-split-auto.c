/**
 * @file test-mpi-split-auto.c
 *
 * Tests the QV_SPLIT_AUTO automatic grouping option. Unlike the other
 * QV_SPLIT_* options, which honor the requested number of pieces exactly,
 * QV_SPLIT_AUTO automatically determines a reasonable grouping and splitting
 * based on the resources being split, the requested split size, and the group
 * size. In doing so it distributes all the resources in the parent scope
 * across the children. This test exercises both possibilities:
 *
 *   1. The group size is smaller than the requested number of pieces. Here the
 *      split size is reduced to match the group size so that no parent resource
 *      is left unused.
 *   2. The group size is >= the requested number of pieces. Here no clamping is
 *      needed, so the requested number of pieces is honored exactly and the
 *      members are distributed across those pieces.
 *
 * In both cases the union of the members' resources must equal the parent's.
 */

#include "quo-vadis-mpi.h"
#include "common-test-utils.h"

int
main(
    int argc,
    char **argv
) {
    MPI_Comm comm = MPI_COMM_WORLD;

    ctu_mpi_check(MPI_Init(&argc, &argv));

    qv_scope_t *base_scope;
    ctu_check(
        qv_mpi_scope(comm, QV_SCOPE_JOB, QV_SCOPE_FLAG_NONE, &base_scope)
    );

    ctu_emit_scope_report(
        base_scope, CTU_SCOPE_KIND_MPI, "     base_scope"
    );

    // The number of members participating in the split.
    int group_size;
    ctu_check(qv_group_size(base_scope, &group_size));

    // The total number of PUs available in the parent scope.
    int parent_npus;
    ctu_check(qv_hw_count(base_scope, QV_HW_PU, &parent_npus));

    // Deliberately request more pieces than there are members. With the other
    // QV_SPLIT_* options this would carve the parent's resources into
    // |npieces| pieces and leave the pieces beyond the group size unused. With
    // QV_SPLIT_AUTO the split size is clamped to the group size so that all
    // parent resources end up distributed across the children.
    int npieces = group_size + 2;

    qv_scope_t *sub_scope;
    ctu_check(qv_split(base_scope, npieces, QV_SPLIT_AUTO, &sub_scope));

    ctu_emit_scope_report(
        sub_scope, CTU_SCOPE_KIND_MPI, "      sub_scope"
    );

    // The number of PUs this member received from the split.
    int my_npus;
    ctu_check(qv_hw_count(sub_scope, QV_HW_PU, &my_npus));

    // Every member should have received a non-empty piece of the parent.
    ctu_assert(
        my_npus > 0,
        "QV_SPLIT_AUTO produced an empty scope (my_npus=%d)", my_npus
    );

    // Since QV_SPLIT_AUTO assigns each member a distinct piece and uses the
    // entire parent, the union of the members' PUs must equal the parent's PU
    // count. Members receive disjoint pieces, so summing PU counts recovers the
    // total number of parent PUs.
    int total_npus = 0;
    ctu_mpi_check(
        MPI_Allreduce(&my_npus, &total_npus, 1, MPI_INT, MPI_SUM, comm)
    );

    ctu_assert(
        total_npus == parent_npus,
        "QV_SPLIT_AUTO did not use all parent resources "
        "(total_npus=%d, parent_npus=%d)", total_npus, parent_npus
    );

    ctu_emit(
        base_scope, CTU_SCOPE_KIND_MPI,
        "QV_SPLIT_AUTO: group_size=%d npieces=%d parent_npus=%d "
        "my_npus=%d total_npus=%d\n",
        group_size, npieces, parent_npus, my_npus, total_npus
    );

    ctu_check(qv_free(sub_scope));

    // Now test the other possibility: the group size is >= the requested split
    // size. Here QV_SPLIT_AUTO has no need to clamp the split size, so it
    // honors |npieces| exactly, carving the parent into that many pieces and
    // distributing the members across them. The entire parent must still be
    // used, so the union of the members' PUs equals the parent's PU count.
    // Multiple members may share the same piece, so we deduplicate by only
    // counting one representative member per piece.
    npieces = (group_size > 1) ? (group_size - 1) : 1;

    ctu_check(qv_split(base_scope, npieces, QV_SPLIT_AUTO, &sub_scope));

    ctu_emit_scope_report(
        sub_scope, CTU_SCOPE_KIND_MPI, "      sub_scope"
    );

    // The number of PUs this member received from the split.
    ctu_check(qv_hw_count(sub_scope, QV_HW_PU, &my_npus));

    // Every member should have received a non-empty piece of the parent.
    ctu_assert(
        my_npus > 0,
        "QV_SPLIT_AUTO produced an empty scope (my_npus=%d)", my_npus
    );

    // Determine this member's rank within its piece. Members that land in the
    // same piece share an intra-piece group; the group's rank tells us who is
    // the piece representative (rank 0). Since the group size is >= the
    // requested split size, QV_SPLIT_AUTO must honor the requested number of
    // pieces exactly (no clamping occurs).
    int my_piece_rank;
    ctu_check(qv_group_rank(sub_scope, &my_piece_rank));

    // Only the representative (rank 0) of each piece contributes its PU count,
    // so summing over representatives recovers the parent's total PU count
    // without double-counting shared pieces.
    int contrib_npus = (my_piece_rank == 0) ? my_npus : 0;
    total_npus = 0;
    ctu_mpi_check(
        MPI_Allreduce(&contrib_npus, &total_npus, 1, MPI_INT, MPI_SUM, comm)
    );

    ctu_assert(
        total_npus == parent_npus,
        "QV_SPLIT_AUTO did not use all parent resources "
        "(total_npus=%d, parent_npus=%d)", total_npus, parent_npus
    );

    // Count the number of distinct pieces (one per representative) and verify
    // the split honored the requested piece count exactly rather than
    // clamping it to the group size.
    int is_rep = (my_piece_rank == 0) ? 1 : 0;
    int num_pieces = 0;
    ctu_mpi_check(
        MPI_Allreduce(&is_rep, &num_pieces, 1, MPI_INT, MPI_SUM, comm)
    );

    ctu_assert(
        num_pieces == npieces,
        "QV_SPLIT_AUTO did not honor the requested split size "
        "(num_pieces=%d, npieces=%d)", num_pieces, npieces
    );

    ctu_emit(
        base_scope, CTU_SCOPE_KIND_MPI,
        "QV_SPLIT_AUTO: group_size=%d npieces=%d parent_npus=%d "
        "my_npus=%d total_npus=%d num_pieces=%d\n",
        group_size, npieces, parent_npus, my_npus, total_npus, num_pieces
    );

    ctu_check(qv_free(sub_scope));

    ctu_check(qv_free(base_scope));

    ctu_mpi_check(MPI_Finalize());

    return EXIT_SUCCESS;
}

/*
 * vim: ft=cpp ts=4 sts=4 sw=4 expandtab
 */
