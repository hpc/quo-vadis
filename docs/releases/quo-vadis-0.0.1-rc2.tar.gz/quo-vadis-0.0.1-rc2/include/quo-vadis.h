/* -*- Mode: C; c-basic-offset:4; indent-tabs-mode:nil -*- */
/*
 * Copyright (c) 2020-2026 Triad National Security, LLC
 *                         All rights reserved.
 *
 * Copyright (c) 2020-2021 Lawrence Livermore National Security, LLC
 *                         All rights reserved.
 *
 * Copyright (c) 2022      Inria.
 *                         All rights reserved.
 *
 * Copyright (c) 2022      Bordeaux INP.
 *                         All rights reserved.
 *
 * This file is part of the quo-vadis project. See the LICENSE file at the
 * top-level directory of this distribution.
 */

/**
 * @file quo-vadis.h
 */

#ifndef QUO_VADIS_H
#define QUO_VADIS_H

#ifdef __cplusplus
extern "C" {
#endif

/** Convenience definition. */
#define QUO_VADIS 1

/** Opaque quo-vadis scope. */
struct qv_scope;
typedef struct qv_scope qv_scope_t;

/**
 * Return codes.
 */
enum {
    /** Success. */
    QV_SUCCESS = 0,
    /** Success, but shut down. */
    QV_SUCCESS_SHUTDOWN,
    /** Unspecified error. */
    QV_ERR,
    /** Environment error. */
    QV_ERR_ENV,
    /** Internal library error. */
    QV_ERR_INTERNAL,
    /** File I/O error. */
    QV_ERR_FILE_IO,
    /** System error. */
    QV_ERR_SYS,
    /** Out of resources. */
    QV_ERR_OOR,
    /** Invalid argument. */
    QV_ERR_INVLD_ARG,
    /** Hardware locality (hwloc) error. */
    QV_ERR_HWLOC,
    /** MPI error. */
    QV_ERR_MPI,
    /** Remote procedure call error. */
    QV_ERR_RPC,
    /** Operation not supported. */
    QV_ERR_NOT_SUPPORTED,
    /** Requested item not found. */
    QV_ERR_NOT_FOUND,
    /** Scope split error. */
    QV_ERR_SPLIT,
    /** Resources unavailable. */
    QV_ERR_UNAVAILABLE
};

/**
 * Intrinsic scope types.
 */
typedef enum {
    /**
     * Include all system resources, including those disallowed by mechanisms
     * such as Linux cgroups. Use this type with care.
     */
    QV_SCOPE_SYSTEM = 0,
    /**
     * Includes all allowed resources on the system. For example, if cgroups are
     * used, using this type will result in a scope containing only resources
     * allowed in the encompassing cgroup.
     */
    QV_SCOPE_USER,
    /**
     * Includes the union of resources available to the calling processes. For
     * example, if the calling processes are bound to a strict subset of the
     * available system resources, then the resulting scope will include
     * strictly that subset.
     */
    QV_SCOPE_JOB,
    /**
     * Like QV_SCOPE_USER, but the group comprises only the calling process.
     */
    QV_SCOPE_PROCESS
} qv_scope_intrinsic_t;

/**
 * Intrinsic scope flags that influence *_scope_get() behavior.
 *
 * Note to developers: long long is guaranteed to be at least 64 bits,
 * which should be plenty for our needs.
 */
typedef long long qv_scope_flags_t;

/**
 * Empty flags, get scope with default behavior.
 */
#define QV_SCOPE_FLAG_NONE           (0LL)

/**
 * Disable use of SMT.
 */
#define QV_SCOPE_FLAG_NO_SMT         (1LL << 0)

/**
 * Attempt to create with resources with high affinity to the parent.
 */
#define QV_SCOPE_FLAG_HINT_CLOSE     (1LL << 1)

/**
 * TODO(skg) Ignored: not yet implemented.
 */
#define QV_SCOPE_FLAG_HINT_EXCLUSIVE (1LL << 2)

/**
 * Hardware object types.
 */
typedef enum {
    QV_HW_MACHINE = 0,
    QV_HW_PACKAGE,
    QV_HW_CORE,
    QV_HW_PU,
    QV_HW_L1CACHE,
    QV_HW_L2CACHE,
    QV_HW_L3CACHE,
    QV_HW_L4CACHE,
    QV_HW_L5CACHE,
    QV_HW_NUMANODE,
    /** Device types. */
    QV_HW_GPU,
    QV_HW_NIC,
    /** Sentinel value. */
    QV_HW_LAST
} qv_hw_type_t;

/**
 * Binding string representation format flags.
 */
typedef int qv_bind_string_flags_t;

/**
 * Output the logical binding.
 */
#define QV_BIND_STRING_LOGICAL  (1 << 0)

/**
 * Output the physical (OS) binding.
 */
#define QV_BIND_STRING_PHYSICAL (1 << 1)

/**
 * Automatic grouping options for qv_split() and qv_split_at(). The
 * following values can be used instead of group_id to influence how automatic
 * task grouping is accomplished.
 */
enum {
    /**
     * Constant used to indicate undefined or unknown integer value. This means
     * that the caller will not be considered in the split, and therefore
     * receive no subscope (a NULL scope is returned to the caller).
     */
    QV_SPLIT_UNDEFINED = -1,
    /**
     * Split and group the provided group automatically. This option attempts to
     * provide a reasonable grouping and splitting based on the resources being
     * split, the requested split size, and the group size. The goal is to make
     * use of the available parent resources sensibly without requiring the
     * caller to select a specific splitting strategy.
     */
    QV_SPLIT_AUTO = -2,
    /**
     * Split the provided group by packing tasks together as tightly as
     * possible onto resources before moving on to the next resource.
     */
    QV_SPLIT_PACKED = -3,
    /**
     * Split the provided group by spreading tasks across the available
     * resources as evenly as possible.
     */
    QV_SPLIT_SPREAD = -4,
    /**
     * Split the provided group by attempting to preserve tasks' current
     * affinities (at time of the split call) as much as possible.
     */
    QV_SPLIT_CLOSE = -5
};

/**
 * Device identifier types.
 */
typedef enum {
    /**
     * Universally Unique Identifier (UUID) string:
     * GPU-00000000-0000-0000-0000-000000000000.
     */
    QV_DEV_ID_UUID = 0,
    /**
     * PCI bus identifier string: 0000:00:00.0.
     */
    QV_DEV_ID_PCI_BUS_ID,
    /**
     * Vendor-visible logical device number (ordinal) as a string:
     * the value used by CUDA_VISIBLE_DEVICES, for example.
     */
    QV_DEV_ID_ORDINAL
} qv_dev_id_type_t;

/**
 * Version query function.
 *
 * @param[out] major Major version.
 *
 * @param[out] minor Minor version.
 *
 * @param[out] patch Patch version.
 *
 * @retval QV_SUCCESS if the operation completed successfully.
 */
int
qv_version(
    int *major,
    int *minor,
    int *patch
);

/**
 * Returns a string describing the provided return code.
 *
 * @param[in] ec The return code to describe.
 *
 * @retval A pointer to a null-terminated, statically allocated string
 * describing the return code, or an empty string if the code is unrecognized.
 * The caller must not free the returned string.
 */
const char *
qv_strerr(
    int ec
);

/**
 * Creates a scope whose group comprises only the calling process.
 *
 * @param[in] iscope The intrinsic scope type used to determine the hardware
 * resources included in the resulting scope.
 *
 * @param[in] flags Flags that influence how the scope is created.
 *
 * @param[out] scope Address of a pointer that will receive the newly created
 * scope. The caller is responsible for freeing this scope with qv_free().
 *
 * @retval QV_SUCCESS if the operation completed successfully.
 */
int
qv_process_scope(
    qv_scope_intrinsic_t iscope,
    qv_scope_flags_t flags,
    qv_scope_t **scope
);

/**
 * Creates a subscope of the provided scope spanning a requested number of
 * hardware objects of a given type.
 *
 * @param[in] scope The parent scope from whose resources the subscope is
 * carved.
 *
 * @param[in] flags Flags that influence how the subscope is created.
 *
 * @param[in] type The hardware object type used to size the subscope.
 *
 * @param[in] nobjs The number of hardware objects of the given type to include
 * in the subscope. Must be non-negative.
 *
 * @param[out] subscope Address of a pointer that will receive the newly created
 * subscope. The caller is responsible for freeing this scope with qv_free().
 *
 * @retval QV_SUCCESS if the operation completed successfully.
 */
int
qv_create_scope(
    qv_scope_t *scope,
    qv_scope_flags_t flags,
    qv_hw_type_t type,
    int nobjs,
    qv_scope_t **subscope
);

/**
 * Returns the caller's group rank in the provided scope.
 *
 * @param[in] scope The scope whose group is queried.
 *
 * @param[out] rank The caller's rank within the scope's group.
 *
 * @retval QV_SUCCESS if the operation completed successfully.
 */
int
qv_group_rank(
    qv_scope_t *scope,
    int *rank
);

/**
 * Returns the scope's underlying group's size.
 *
 * @param[in] scope The scope whose group is queried.
 *
 * @param[out] group_size The number of members in the scope's group.
 *
 * @retval QV_SUCCESS if the operation completed successfully.
 */
int
qv_group_size(
    qv_scope_t *scope,
    int *group_size
);

/**
 * Returns the number of hardware objects contained within the provided scope.
 *
 * @param[in] scope The scope whose hardware objects are counted.
 *
 * @param[in] obj The type of hardware object to count.
 *
 * @param[out] nobjs The number of hardware objects of the given type contained
 * within the scope.
 *
 * @retval QV_SUCCESS if the operation completed successfully.
 */
int
qv_hw_count(
    qv_scope_t *scope,
    qv_hw_type_t obj,
    int *nobjs
);

/**
 * Returns a string identifier for a device in the provided scope.
 *
 * @param[in] scope The scope whose devices are queried.
 *
 * @param[in] dev_obj The device hardware object type to query, such as
 * QV_HW_GPU or QV_HW_NIC.
 *
 * @param[in] dev_index The zero-based index selecting which device of the
 * given type to identify. Must be non-negative and less than the number of
 * such devices in the scope.
 *
 * @param[in] id_type The device identifier format to return, such as
 * QV_DEV_ID_UUID, QV_DEV_ID_PCI_BUS_ID, or QV_DEV_ID_ORDINAL.
 *
 * @param[out] dev_id Address of a pointer that will receive a newly allocated,
 * null-terminated string containing the device identifier. The caller is
 * responsible for freeing this string.
 *
 * @retval QV_SUCCESS if the operation completed successfully.
 */
int
qv_dev_id(
    qv_scope_t *scope,
    qv_hw_type_t dev_obj,
    int dev_index,
    qv_dev_id_type_t id_type,
    char **dev_id
);

/**
 * Synchronizes all members of the provided scope's group.
 *
 * @param[in] scope The scope whose group participates in the barrier. All
 * members of the group must call this function because it blocks until every
 * member has arrived.
 *
 * @retval QV_SUCCESS if the operation completed successfully.
 */
int
qv_barrier(
    qv_scope_t *scope
);

/**
 * Splits the provided scope into a number of pieces, returning the subscope
 * the caller belongs to.
 *
 * @param[in] scope The scope to split.
 *
 * @param[in] npieces The number of pieces to split the scope into.
 *
 * @param[in] group_id The color selecting which piece the caller joins, or
 * QV_SPLIT_UNDEFINED to opt out of the split (see below), or one of the
 * automatic QV_SPLIT_* grouping constants.
 *
 * @param[out] subscope The resulting subscope the caller belongs to. If the
 * caller provided QV_SPLIT_UNDEFINED, it is excluded from the split and
 * *subscope is set to NULL to signal that no subscope was returned.
 *
 * @retval QV_SUCCESS if the operation completed successfully.
 */
int
qv_split(
    qv_scope_t *scope,
    int npieces,
    int group_id,
    qv_scope_t **subscope
);

/**
 * Splits the provided scope at the given hardware object type, returning the
 * subscope the caller belongs to.
 *
 * @param[in] scope The scope to split.
 *
 * @param[in] type The hardware object type to split at.
 *
 * @param[in] group_id The color selecting which piece the caller joins, or
 * QV_SPLIT_UNDEFINED to opt out of the split (see below), or one of the
 * automatic QV_SPLIT_* grouping constants.
 *
 * @param[out] subscope The resulting subscope the caller belongs to. If the
 * caller provided QV_SPLIT_UNDEFINED, it is excluded from the split and
 * *subscope is set to NULL to signal that no subscope was returned.
 *
 * @retval QV_SUCCESS if the operation completed successfully.
 */
int
qv_split_at(
    qv_scope_t *scope,
    qv_hw_type_t type,
    int group_id,
    qv_scope_t **subscope
);

/**
 * Pushes the provided scope's resources onto the caller's binding stack,
 * binding the caller to the scope's resources.
 *
 * @param[in] scope The scope whose resources the caller is bound to.
 *
 * @retval QV_SUCCESS if the operation completed successfully.
 */
int
qv_bind_push(
    qv_scope_t *scope
);

/**
 * Pops the most recent binding off the caller's binding stack, restoring the
 * previous binding established before the corresponding qv_bind_push() call.
 *
 * @param[in] scope The scope whose binding is popped.
 *
 * @retval QV_SUCCESS if the operation completed successfully.
 */
int
qv_bind_pop(
    qv_scope_t *scope
);

/**
 * Returns a string representation of the caller's current binding within the
 * provided scope.
 *
 * @param[in] scope The scope in which the caller's binding is queried.
 *
 * @param[in] flags Format flags controlling the representation, such as
 * QV_BIND_STRING_LOGICAL or QV_BIND_STRING_PHYSICAL.
 *
 * @param[out] str Address of a pointer that will receive a newly allocated,
 * null-terminated string describing the binding. The caller is responsible for
 * freeing this string.
 *
 * @retval QV_SUCCESS if the operation completed successfully.
 */
int
qv_bind_string(
    qv_scope_t *scope,
    qv_bind_string_flags_t flags,
    char **str
);

/**
 * Releases resources associated with the provided scope.
 *
 * @param[in] scope The scope to free.
 *
 * @retval QV_SUCCESS if the operation completed successfully.
 */
int
qv_free(
    qv_scope_t *scope
);

#ifdef __cplusplus
}
#endif

#endif

/*
 * vim: ft=cpp ts=4 sts=4 sw=4 expandtab
 */
